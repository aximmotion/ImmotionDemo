/*
 * IMMOTION · branchement de l'assistant à vos agents IA
 *
 * Tant que "endpoint" est vide, l'assistant répond avec ses réponses intégrées
 * (prix des 100 communes, biens en vente et en location, honoraires, rendez-vous...).
 *
 * Pour tester un de vos agents, indiquez ici l'adresse (URL) qui le fait répondre.
 * L'assistant lui envoie, en POST et en JSON :
 *   { "message": "texte du visiteur",
 *     "history": [ { "role": "user" | "assistant", "text": "..." }, ... ],
 *     "page": "bien.html",
 *     "lang": "fr" | "de" | "en" }
 * et attend en retour, en JSON :
 *   { "reply": "réponse à afficher",
 *     "actions": [ { "label": "Voir le bien", "href": "bien.html" } ]   (facultatif) }
 *
 * Si l'agent ne répond pas (erreur, délai de 20 s dépassé), l'assistant revient
 * automatiquement à ses réponses intégrées.
 *
 * Ne mettez jamais de clé d'API secrète dans ce fichier : il est public.
 * L'adresse doit être celle de votre propre service (par exemple un webhook n8n),
 * qui garde la clé de son côté.
 */
window.IMMOTION_AGENT = {
  endpoint: "",
  name: "Assistant IMMOTION"
};
