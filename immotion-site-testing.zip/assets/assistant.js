/* IMMOTION · assistant du site (bouton rond en bas à droite, présent sur toutes les pages). */
(function () {
  'use strict';
  if (window.__immotionAssistant) return;
  window.__immotionAssistant = true;

  var CFG = window.IMMOTION_AGENT || {};
  var COMMUNES = [["Beaufort","Echternach",7250,1,5497,0,3102],["Bech","Echternach",7620,1,5780,1,1370],["Beckerich","Redange",6890,1,5116,0,2913],["Berdorf","Echternach",6600,1,5010,1,2293],["Bertrange","Luxembourg",11277,0,8371,0,9489],["Bettembourg","Esch-sur-Alzette",7522,0,6416,0,11651],["Bettendorf","Diekirch",7820,1,5546,0,3051],["Betzdorf","Grevenmacher",8850,1,6461,0,4127],["Bissen","Mersch",7867,0,5898,0,3564],["Biwer","Grevenmacher",8380,1,6119,0,1902],["Boulaide","Wiltz",6150,1,4604,0,1579],["Bourscheid","Diekirch",7180,1,5090,1,1784],["Bous-Waldbredimus","Remich",8133,0,5890,0,3368],["Clervaux","Clervaux",5896,0,4906,0,6327],["Colmar-Berg","Mersch",6840,0,5401,0,2471],["Consdorf","Echternach",7110,1,5398,0,2093],["Contern","Luxembourg",9389,0,6762,0,5006],["Dalheim","Remich",7056,0,6914,0,2377],["Diekirch","Diekirch",7579,0,4826,0,7398],["Differdange","Esch-sur-Alzette",7206,0,5106,0,31421],["Dippach","Capellen",8446,0,6047,0,4721],["Dudelange","Esch-sur-Alzette",7134,0,5279,0,22379],["Echternach","Echternach",6612,0,5248,0,6031],["Ell","Redange",7150,1,5306,0,1668],["Erpeldange-sur-Sûre","Diekirch",6810,1,4830,1,2662],["Esch-sur-Alzette","Esch-sur-Alzette",7406,0,5127,0,38275],["Esch-sur-Sûre","Wiltz",5671,0,4648,0,3373],["Ettelbruck","Diekirch",6551,0,4754,0,10212],["Feulen","Diekirch",6690,1,4739,0,2431],["Fischbach","Mersch",8250,1,5790,1,1344],["Flaxweiler","Grevenmacher",7750,1,5658,0,2268],["Frisange","Esch-sur-Alzette",7883,0,6167,0,5039],["Garnich","Capellen",7900,0,6687,0,2421],["Goesdorf","Wiltz",6218,0,4476,0,1682],["Grevenmacher","Grevenmacher",8566,0,5712,0,5297],["Groussbus-Wal","Redange",5980,1,4440,0,2390],["Habscht","Capellen",7120,0,5493,0,5337],["Heffingen","Mersch",8211,0,5361,0,1597],["Helperknapp","Mersch",6897,0,5541,0,5326],["Hesperange","Luxembourg",10071,0,7938,0,17264],["Junglinster","Grevenmacher",8750,0,7494,0,9139],["Kayl","Esch-sur-Alzette",7293,0,5083,0,9989],["Kehlen","Capellen",8208,0,6078,0,7449],["Kiischpelt","Wiltz",6060,1,4530,1,1309],["Koerich","Capellen",6928,0,6502,0,2814],["Kopstal","Capellen",8831,0,8726,0,4740],["Käerjeng","Capellen",8724,0,6206,0,11343],["Lac de la Haute-Sûre","Wiltz",5980,1,4476,0,2320],["Larochette","Mersch",6832,0,4480,1,2241],["Lenningen","Remich",6510,1,5159,0,2114],["Leudelange","Esch-sur-Alzette",8696,0,7664,0,2765],["Lintgen","Mersch",9306,0,6196,0,3484],["Lorentzweiler","Mersch",9287,0,5439,0,4760],["Luxembourg","Luxembourg",12229,0,8638,0,137678],["Mamer","Capellen",9693,0,8051,0,11583],["Manternach","Grevenmacher",7660,1,5590,1,2340],["Mersch","Mersch",9513,0,6194,0,10888],["Mertert","Grevenmacher",6973,0,5690,0,5685],["Mertzig","Diekirch",8310,1,5892,0,2435],["Mondercange","Esch-sur-Alzette",7138,0,6607,0,7312],["Mondorf-les-Bains","Remich",8013,0,6250,0,5524],["Niederanven","Luxembourg",10202,0,7555,0,7161],["Nommern","Mersch",8100,1,5690,1,1516],["Parc Hosingen","Clervaux",6030,1,4646,0,4407],["Préizerdaul","Redange",7440,1,5524,0,1802],["Putscheid","Vianden",7620,1,5660,1,1191],["Pétange","Esch-sur-Alzette",7008,0,4952,0,21290],["Rambrouch","Redange",6420,1,4762,0,5064],["Reckange-sur-Mess","Esch-sur-Alzette",8764,0,5678,0,2957],["Redange/Attert","Redange",6920,1,5140,1,3149],["Reisdorf","Diekirch",8630,1,6116,0,1422],["Remich","Remich",7756,0,6492,0,4156],["Roeser","Esch-sur-Alzette",8208,0,7317,0,7184],["Rosport-Mompach","Echternach",6410,1,4863,0,3795],["Rumelange","Esch-sur-Alzette",6518,0,4988,0,5767],["Saeul","Redange",6980,1,5180,1,1081],["Sandweiler","Luxembourg",10030,1,7450,0,3872],["Sanem","Esch-sur-Alzette",7406,0,5486,0,19611],["Schengen","Remich",6660,1,5277,0,5265],["Schieren","Diekirch",7628,0,5430,1,2172],["Schifflange","Esch-sur-Alzette",7406,0,5658,0,11674],["Schuttrange","Luxembourg",9288,0,6469,0,4500],["Stadtbredimus","Remich",7390,1,5852,0,2023],["Steinfort","Capellen",8642,0,6142,0,6154],["Steinsel","Luxembourg",9839,0,6823,0,6186],["Strassen","Luxembourg",10870,0,8663,0,10831],["Tandel","Vianden",7620,1,5660,1,2374],["Troisvierges","Clervaux",5720,1,4405,0,3708],["Useldange","Redange",6950,1,5156,0,2181],["Vallée de l'Ernz","Diekirch",6600,1,4682,0,2963],["Vianden","Vianden",5750,1,4270,0,2243],["Vichten","Redange",7850,1,5830,1,1453],["Waldbillig","Echternach",7230,1,5488,0,1999],["Walferdange","Luxembourg",9657,0,7930,0,9256],["Weiler-la-Tour","Luxembourg",8046,0,5993,0,2523],["Weiswampach","Clervaux",6652,0,4550,1,2699],["Wiltz","Wiltz",5759,0,4171,0,8538],["Wincrange","Clervaux",5610,1,4316,0,5038],["Winseler","Wiltz",5960,1,4460,1,1590],["Wormeldange","Grevenmacher",8615,0,5283,0,3249]];
  var PAGE = (location.pathname.split('/').pop() || 'index.html');
  var STORE = 'immotion-assistant-v1';

  /* ---------- Données du site ---------- */
  var VENTE = [
    { t: '3 chambres avec terrasse', type: 'appartement', c: 'Strassen', m2: 92, ch: 3, prix: 1000000, cl: 'A', href: 'bien.html' },
    { t: 'Maison familiale avec jardin', type: 'maison', c: 'Bertrange', m2: 165, ch: 4, prix: 1380000, cl: 'B', href: 'bien.html' },
    { t: 'Studio lumineux proche tram', type: 'appartement', c: 'Luxembourg', m2: 52, ch: 1, prix: 598000, cl: 'A', href: 'bien.html' },
    { t: 'Maison mitoyenne à rénover', type: 'maison', c: 'Mamer', m2: 140, ch: 3, prix: 1090000, cl: 'D', href: 'bien.html' },
    { t: '2 chambres, résidence récente', type: 'appartement', c: 'Hesperange', m2: 80, ch: 2, prix: 849000, cl: 'B', href: 'bien.html' },
    { t: '2 chambres, quartier Belval', type: 'appartement', c: 'Esch-sur-Alzette', m2: 74, ch: 2, prix: 548000, cl: 'C', href: 'bien.html' }
  ];
  var LOC = [
    { t: '2 chambres avec balcon', type: 'appartement', c: 'Luxembourg', m2: 78, ch: 2, prix: 2650, ch2: 220, href: 'location.html' },
    { t: '3 chambres, résidence neuve', type: 'appartement', c: 'Strassen', m2: 95, ch: 3, prix: 3100, ch2: 260, href: 'location.html' },
    { t: "Studio meublé près de l'université", type: 'studio', c: 'Esch-sur-Alzette', m2: 38, ch: 0, prix: 1350, ch2: 150, href: 'location.html' },
    { t: 'Maison 4 chambres avec jardin', type: 'maison', c: 'Bertrange', m2: 170, ch: 4, prix: 4600, ch2: null, href: 'location.html' },
    { t: 'Chambre dans une colocation de 4', type: 'colocation', c: 'Luxembourg', m2: 16, ch: 1, prix: 950, ch2: 120, href: 'location.html' },
    { t: '1 chambre avec parking', type: 'appartement', c: 'Hesperange', m2: 55, ch: 1, prix: 1780, ch2: 180, href: 'location.html' }
  ];

  /* ---------- Outils ---------- */
  function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’']/g, ' '); }
  function fmt(n) { return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' '); }
  function eur(n) { return fmt(n) + ' €'; }
  function has(t, words) { for (var i = 0; i < words.length; i++) if (t.indexOf(words[i]) !== -1) return true; return false; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function detectLang(t) {
    var n = norm(t);
    if (/\b(hallo|guten|ich|wohnung|haus|kaufen|mieten|preis|wie viel|danke|bitte|termin)\b/.test(n)) return 'de';
    if (/\b(hello|hi|i want|buy|rent|house|flat|apartment for|price of|how much|thanks|please|appointment|what is)\b/.test(n)) return 'en';
    return 'fr';
  }
  var T = {
    fr: { hello: "Moien ! Je peux vous aider à trouver un bien, connaître les prix d'une commune, estimer le vôtre ou réserver un rendez-vous.", none: "Je n'ai pas de réponse sûre à cette question. Un conseiller peut vous répondre rapidement.", rdv: 'Prendre rendez-vous', agence: 'Contacter l’agence', all: 'Voir tous les biens', allLoc: 'Voir toutes les locations', est: 'Estimer mon bien', carte: 'Ouvrir la carte', one: 'J’ai 1 bien qui correspond :', many: 'J’ai %n biens qui correspondent :', oneL: 'J’ai 1 location qui correspond :', manyL: 'J’ai %n locations qui correspondent :', noneB: 'Aucun bien ne correspond exactement%c pour le moment.', near: ' Voici les plus proches de votre recherche :', alert: ' Créez une alerte pour être prévenu en premier.', at: ' à ', price: '%n (canton %k) : appartements %a/m², maisons %m/m².', src: 'Prix annoncés des 12 derniers mois, Observatoire de l’Habitat.', estd: ' « ≈ » : estimation IMMOTION, faute d’annonces suffisantes.', forM2: ' Pour %s m², comptez environ %v.', month: ' / mois', biensA: 'Biens à ' },
    en: { hello: 'Hello! I can help you find a property, check prices in any commune, value your home or book an appointment.', none: "I don't have a reliable answer to that. An advisor can reply quickly.", rdv: 'Book an appointment', agence: 'Contact the agency', all: 'See all properties', allLoc: 'See all rentals', est: 'Value my property', carte: 'Open the map', one: 'I have 1 matching property:', many: 'I have %n matching properties:', oneL: 'I have 1 matching rental:', manyL: 'I have %n matching rentals:', noneB: 'Nothing matches exactly%c right now.', near: ' Here are the closest matches:', alert: ' Create an alert to hear first.', at: ' in ', price: '%n (canton %k): apartments %a/m², houses %m/m².', src: 'Asking prices over the last 12 months, Observatoire de l’Habitat.', estd: ' “≈”: IMMOTION estimate, too few listings.', forM2: ' For %s m², expect about %v.', month: ' / month', biensA: 'Properties in ' },
    de: { hello: 'Moien! Ich helfe Ihnen, eine Immobilie zu finden, die Preise einer Gemeinde zu sehen, Ihre Immobilie zu bewerten oder einen Termin zu buchen.', none: 'Darauf habe ich keine sichere Antwort. Ein Berater antwortet Ihnen schnell.', rdv: 'Termin vereinbaren', agence: 'Agentur kontaktieren', all: 'Alle Objekte', allLoc: 'Alle Mietobjekte', est: 'Immobilie bewerten', carte: 'Karte öffnen', one: 'Ich habe 1 passendes Objekt:', many: 'Ich habe %n passende Objekte:', oneL: 'Ich habe 1 passendes Mietobjekt:', manyL: 'Ich habe %n passende Mietobjekte:', noneB: 'Derzeit passt nichts genau%c.', near: ' Hier die ähnlichsten Objekte:', alert: ' Legen Sie einen Suchauftrag an.', at: ' in ', price: '%n (Kanton %k): Wohnungen %a/m², Häuser %m/m².', src: 'Angebotspreise der letzten 12 Monate, Observatoire de l’Habitat.', estd: ' „≈“: IMMOTION-Schätzung, zu wenige Inserate.', forM2: ' Für %s m² rechnen Sie mit etwa %v.', month: ' / Monat', biensA: 'Objekte in ' }
  };

  function findCommune(t) {
    var n = ' ' + norm(t).replace(/[^a-z0-9-]+/g, ' ') + ' ';
    var best = null;
    for (var i = 0; i < COMMUNES.length; i++) {
      var name = norm(COMMUNES[i][0]);
      var alt = name.replace(/-/g, ' ');
      if (n.indexOf(' ' + name + ' ') !== -1 || n.indexOf(' ' + alt + ' ') !== -1) {
        if (!best || name.length > norm(best[0]).length) best = COMMUNES[i];
      }
    }
    var ALIAS = { esch: 'Esch-sur-Alzette', belval: 'Esch-sur-Alzette', diff: 'Differdange', dude: 'Dudelange', ettel: 'Ettelbruck', 'redange': 'Redange/Attert' };
    if (!best) for (var k in ALIAS) if (n.indexOf(' ' + k + ' ') !== -1) for (var q = 0; q < COMMUNES.length; q++) if (COMMUNES[q][0] === ALIAS[k]) best = COMMUNES[q];
    if (!best && /\b(luxembourg[- ]ville|lux[- ]ville|kirchberg|limpertsberg|belair|gare)\b/.test(n)) {
      for (var j = 0; j < COMMUNES.length; j++) if (COMMUNES[j][0] === 'Luxembourg') best = COMMUNES[j];
    }
    return best;
  }
  function parseBudget(t) {
    var n = norm(t).replace(/ | /g, ' ');
    var m = n.match(/(\d+(?:[.,]\d+)?)\s*(millions?|mio|m(?![²2]))(?![a-z²])/);
    if (m) return parseFloat(m[1].replace(',', '.')) * 1e6;
    m = n.match(/(\d+(?:[.,]\d+)?)\s*(k|k€|000)\b/);
    if (m) return parseFloat(m[1].replace(',', '.')) * 1000;
    m = n.match(/(\d[\d ]{2,})\s*(€|eur|euros?)/);
    if (m) return parseInt(m[1].replace(/ /g, ''), 10);
    return null;
  }
  function parseRooms(t) { var m = norm(t).match(/(\d)\s*(ch\b|chambres?|bedrooms?|zimmer|schlafzimmer|pieces?)/); return m ? +m[1] : null; }
  function parseM2(t) { var m = norm(t).match(/(\d{2,4})\s*(m2|m²|metres? carres?|sqm|qm)/); return m ? +m[1] : null; }
  function parseType(t) {
    var n = norm(t);
    if (has(n, ['maison', 'house', 'haus'])) return 'maison';
    if (has(n, ['studio'])) return 'studio';
    if (has(n, ['colocation', 'coloc', 'flatshare', 'wg'])) return 'colocation';
    if (has(n, ['appartement', 'appart', 'apartment', 'flat', 'wohnung'])) return 'appartement';
    return null;
  }

  /* ---------- Cerveau intégré ---------- */
  function localAnswer(text) {
    var L = detectLang(text), tr = T[L], n = norm(text);
    var commune = findCommune(text), budget = parseBudget(text), rooms = parseRooms(text), m2 = parseM2(text), type = parseType(text);
    var A = function (label, href) { return { label: label, href: href }; };

    if (/^\s*(bonjour|bonsoir|salut|moien|hello|hi|hallo|guten tag|coucou)\b/.test(n) && n.length < 30)
      return { reply: tr.hello, actions: [A(tr.all, 'acheter.html'), A(tr.est, 'estimer-bien.html'), A(tr.rdv, 'rdv-choix.html')] };

    var wantsRent = has(n, ['louer', 'location', 'locataire', 'loyer', 'rent', 'mieten', 'miete', 'colocation']) && !has(n, ['mise en location', 'gestion', 'honoraire', 'frais']);
    var wantsBuy = has(n, ['acheter', 'achat', 'acquerir', 'buy', 'kaufen', 'a vendre', 'for sale', 'trouver un bien', 'cherche', 'search', 'suche']) || ((rooms || budget || type) && !wantsRent && !has(n, ['estim', 'vaut', 'valeur']));

    var priceQ = has(n, ['prix', 'price', 'preis', 'combien coute', 'how much', 'wie viel', 'wieviel', 'au m2', 'per m2', 'pro m2', 'cher', 'expensive', 'teuer']);
    function priceAnswer(c) {
      var sq = function (v, e) { return (e ? '≈ ' : '') + eur(v); };
      var t2 = tr.price.replace('%n', c[0]).replace('%k', c[1]).replace('%a', sq(c[2], c[3])).replace('%m', sq(c[4], c[5]));
      var ex = tr.src + ((c[3] || c[5]) ? tr.estd : '') + (m2 ? tr.forM2.replace('%s', m2).replace('%v', eur((type === 'maison' ? c[4] : c[2]) * m2)) : '');
      return { reply: t2, extra: ex, actions: [A(tr.carte, 'carte.html'), A(tr.biensA + c[0], 'acheter.html'), A(tr.est, 'estimer-bien.html')] };
    }
    if (priceQ && commune && !rooms && !budget && !has(n, ['estim', 'vaut', 'valeur', 'louer', 'rent', 'mieten'])) return priceAnswer(commune);

    if (has(n, ['off-market', 'off market', 'offmarket', 'sans annonce', 'discret']))
      return { reply: "L'off-market, ce sont des biens vendus sans annonce publique. Ils sont présentés d'abord aux acheteurs dont le financement est vérifié. Vous pouvez demander l'accès en deux minutes.", actions: [A("Demander l'accès off-market", 'offmarket.html')] };

    if (has(n, ['taux', 'credit', 'pret', 'bce', 'interest', 'mortgage', 'zins', 'kredit']))
      return { reply: 'Le taux variable moyen des crédits immobiliers était de 3,19 % en juin 2026 (BCL). La BCE a relevé son taux de dépôt à 2,50 % le 10 septembre 2026. Le simulateur de chaque fiche calcule votre mensualité.', actions: [A('Simuler une mensualité', 'bien.html#simulateur'), A('Guide pour acheter', 'guide-acheter.html#pret')] };

    if (has(n, ['bellegen', 'bëllegen', 'akt', 'aide', 'prime', 'subvention']))
      return { reply: "Le Bëllegen Akt est un crédit d'impôt sur les droits d'enregistrement : 40 000 € par acheteur aujourd'hui pour une résidence principale. Un relèvement à 45 000 € est à l'étude à la Chambre.", actions: [A('Les aides de l’État', 'guide-acheter.html#aides'), A('Calculer les frais', 'bien.html#frais')] };

    if (has(n, ['frais de notaire', 'droits d enregistrement', 'frais d acte', 'notaire']))
      return { reply: "Au Luxembourg, les droits d'enregistrement et de transcription représentent 7 % du prix, avant le Bëllegen Akt. Chaque fiche de bien les calcule pour vous.", actions: [A('Calculer les frais', 'bien.html#frais'), A('Guide pour acheter', 'guide-acheter.html')] };

    if (has(n, ['honoraire', 'commission', 'frais d agence', 'tarif', 'combien prenez', 'fees', 'gebuhr', 'provision']))
      return { reply: "Mise en location : un mois de loyer plus 17 % de TVA, partagé à parts égales entre propriétaire et locataire depuis le 1er août 2024. Gestion locative : 4 % HTVA des loyers encaissés (formule Essentielle) ou 5 % HTVA avec assurance loyers impayés (Sérénité). Le détail des honoraires de vente est sur la page Honoraires.", actions: [A('Voir les honoraires', 'honoraires.html'), A('La gestion locative', 'gestion.html')] };

    if (has(n, ['gestion', 'gerer', 'faire gerer', 'property management', 'verwaltung']))
      return { reply: "Nous gérons votre bien de A à Z : recherche du locataire, bail, loyers, charges, travaux. Trois formules : Mise en location (1 mois + TVA), Essentielle (4 % HTVA), Sérénité (5 % HTVA avec assurance loyers impayés).", actions: [A('Découvrir la gestion', 'gestion.html'), A('Signer un mandat', 'mandat.html')] };

    if (has(n, ['estim', 'combien vaut', 'valeur de mon', 'vendre mon', 'valuation', 'value my', 'bewert', 'verkaufen']) || (has(n, ['vendre', 'sell']) && !wantsBuy)) {
      if (commune && m2) {
        var isHouse = type === 'maison';
        var pm2 = isHouse ? commune[4] : commune[2], estd = isHouse ? commune[5] : commune[3];
        var mid = pm2 * m2;
        return { reply: 'Première fourchette pour ' + (isHouse ? 'une maison' : 'un appartement') + ' de ' + m2 + ' m² à ' + commune[0] + ' : entre ' + eur(mid * 0.93) + ' et ' + eur(mid * 1.07), extra: 'Base : ' + (estd ? '≈ ' : '') + eur(pm2) + '/m² (prix annoncés' + (estd ? ', estimation IMMOTION' : ', Observatoire de l’Habitat') + '). Un conseiller affine ce chiffre après une visite.', actions: [A('Affiner mon estimation', 'estimer-bien.html'), A(tr.rdv, 'rdv-choix.html')] };
      }
      return { reply: "L'estimation en ligne est gratuite et prend deux minutes : le type de bien, la commune, la surface et l'état. Dites-moi par exemple « maison de 140 m² à Mamer » et je vous donne une première fourchette.", actions: [A(tr.est, 'estimer-bien.html')] };
    }

    if (has(n, ['rendez-vous', 'rendez vous', 'rdv', 'visite', 'visiter', 'appointment', 'termin', 'besichtigung', 'rencontrer']))
      return { reply: 'Vous pouvez réserver un créneau en ligne avec le conseiller de votre choix, en agence, en visio ou sur place. La confirmation est immédiate.', actions: [A(tr.rdv, 'rdv-choix.html'), A('Nos conseillers', 'agence.html')] };

    if (wantsRent) {
      var r = LOC.filter(function (b) {
        return (!commune || b.c === commune[0]) && (!rooms || b.ch >= rooms) && (!budget || b.prix <= budget) && (!type || b.type === type || (type === 'appartement' && b.type === 'studio'));
      });
      if (!r.length) return { reply: tr.noneB.replace('%c', commune ? tr.at + commune[0] : '') + tr.alert, actions: [A(tr.allLoc, 'louer.html'), A('Créer une alerte', 'recherche-location.html')] };
      return { reply: r.length === 1 ? tr.oneL : tr.manyL.replace('%n', r.length), items: r.slice(0, 3).map(function (b) { return { title: b.t, sub: b.c + ' · ' + b.m2 + ' m² · ' + eur(b.prix) + tr.month, href: b.href }; }), actions: [A(tr.allLoc, 'louer.html'), A('Préparer mon dossier', 'dossier-locataire.html')] };
    }

    if (wantsBuy) {
      var v = VENTE.filter(function (b) {
        return (!commune || b.c === commune[0]) && (!rooms || b.ch >= rooms) && (!budget || b.prix <= budget) && (!type || b.type === type);
      });
      if (!v.length) {
        var near = VENTE.filter(function (b) { return (!budget || b.prix <= budget) && (!rooms || b.ch >= rooms) && (!type || b.type === type); });
        return { reply: tr.noneB.replace('%c', commune ? tr.at + commune[0] : '') + (near.length ? tr.near : tr.alert), items: near.slice(0, 3).map(function (b) { return { title: b.t, sub: b.c + ' · ' + b.m2 + ' m² · ' + eur(b.prix), href: b.href }; }), actions: [A('Créer une alerte', 'recherche.html'), A('Accès off-market', 'offmarket.html')] };
      }
      return { reply: v.length === 1 ? tr.one : tr.many.replace('%n', v.length), items: v.slice(0, 3).map(function (b) { return { title: b.t, sub: b.c + ' · ' + b.m2 + ' m² · ' + b.ch + ' ch. · ' + eur(b.prix), href: b.href }; }), actions: [A(tr.all, 'acheter.html'), A(tr.rdv, 'rdv-choix.html')] };
    }

    if (commune || has(n, ['prix', 'price', 'preis', 'm2', 'm²', 'cher', 'combien coute'])) {
      if (!commune) return { reply: 'Les prix au m² des 100 communes sont sur la carte. Dites-moi une commune, par exemple « prix à Bertrange ».', actions: [A(tr.carte, 'carte.html')] };
      return priceAnswer(commune);
    }

    if (has(n, ['contact', 'telephone', 'appeler', 'adresse', 'horaire', 'email', 'e-mail', 'joindre', 'call']))
      return { reply: 'Vous pouvez nous écrire depuis la page Contact ou réserver directement un appel avec un conseiller.', actions: [A(tr.agence, 'agence.html#nous-ecrire'), A(tr.rdv, 'rdv-choix.html')] };
    if (has(n, ['newsletter', 'abonner', 'inscri']))
      return { reply: 'Chaque mois, les chiffres vérifiés du marché luxembourgeois dans votre boîte e-mail. Une seule lettre par mois, désinscription en un clic.', actions: [A("S'abonner", 'newsletter.html')] };
    if (has(n, ['espace client', 'mon espace', 'connexion', 'compte', 'login', 'favori']))
      return { reply: 'Votre espace client réunit vos favoris, alertes, visites, documents et messages. La connexion se fait par lien envoyé par e-mail, sans mot de passe.', actions: [A('Se connecter', 'client-connexion.html')] };
    if (has(n, ['emploi', 'recrut', 'job', 'poste', 'carriere', 'travailler chez']))
      return { reply: 'Nous recrutons. Les postes ouverts et la candidature en ligne sont sur la page Nous rejoindre.', actions: [A('Voir les postes', 'recrutement.html')] };
    if (has(n, ['neuf', 'vefa', 'programme', 'plan']))
      return { reply: 'Nos programmes neufs (VEFA) sont présentés avec leurs lots disponibles, plans et dates de livraison.', actions: [A('Programmes neufs', 'programmes.html')] };
    if (has(n, ['merci', 'thanks', 'danke']))
      return { reply: 'Avec plaisir ! Autre chose ?', actions: [] };

    return { reply: tr.none, actions: [A(tr.rdv, 'rdv-choix.html'), A(tr.agence, 'agence.html#nous-ecrire'), A('Questions fréquentes', 'faq.html')] };
  }

  /* ---------- Agent distant (vos agents IA) ---------- */
  function remoteAnswer(text, history) {
    var ctrl = window.AbortController ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 20000);
    return fetch(CFG.endpoint, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text, history: history, page: PAGE, lang: detectLang(text) }),
      signal: ctrl ? ctrl.signal : undefined
    }).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(function (d) { clearTimeout(timer); if (!d || !d.reply) throw new Error('réponse vide'); return { reply: String(d.reply), actions: Array.isArray(d.actions) ? d.actions : [] }; })
      .catch(function (e) { clearTimeout(timer); console.warn('[assistant] agent indisponible, réponse intégrée', e); var a = localAnswer(text); return a; });
  }

  /* ---------- État (conservé pendant la visite) ---------- */
  var state = { open: false, msgs: [] };
  try { var saved = JSON.parse(sessionStorage.getItem(STORE) || 'null'); if (saved && Array.isArray(saved.msgs)) state = saved; } catch (e) {}
  function save() { try { sessionStorage.setItem(STORE, JSON.stringify({ open: state.open, msgs: state.msgs.slice(-40) })); } catch (e) {} }

  /* ---------- Interface ---------- */
  var css = '' +
    '#imx{position:fixed;right:24px;bottom:24px;z-index:2147483000;font-family:Archivo,system-ui,sans-serif;color:#121212}' +
    '.imx *{box-sizing:border-box}' +
    '.imx .fab{width:64px;height:64px;border-radius:50%;border:2px solid #FF6A1F;background:#1F3A2E;display:grid;place-items:center;box-shadow:0 14px 34px rgba(18,18,18,.35);cursor:pointer;transition:transform .2s ease}' +
    '.imx .fab:hover{transform:scale(1.06)}.imx .fab:focus-visible,.imx button:focus-visible,.imx a:focus-visible{outline:3px solid #FF6A1F;outline-offset:2px}.imx form:focus-within{box-shadow:0 0 0 2px #FF6A1F}' +
    '.imx .tip{position:absolute;right:76px;bottom:6px;width:240px;background:#EDE6D6;border-radius:16px 16px 4px 16px;padding:12px 14px;box-shadow:0 14px 34px rgba(18,18,18,.28);font-size:13px;line-height:1.45;color:rgba(18,18,18,.75);opacity:0;transform:translateX(10px);pointer-events:none;transition:opacity .2s,transform .2s}' +
    '.imx .tip b{display:block;color:#121212;font-size:14px;margin-bottom:2px}#imx:not(.open) .fab:hover+.tip,#imx:not(.open) .fab:focus-visible+.tip{opacity:1;transform:none}' +
    '.imx .panel{position:absolute;right:0;bottom:78px;width:380px;max-width:calc(100vw - 32px);height:min(600px,calc(100vh - 120px));background:#121212;color:#EDE6D6;border-radius:22px;overflow:hidden;display:none;flex-direction:column;box-shadow:0 24px 60px rgba(18,18,18,.45);border:1px solid rgba(237,230,214,.16)}' +
    '#imx.open .panel{display:flex;animation:imxIn .22s cubic-bezier(.2,.8,.2,1)}@keyframes imxIn{from{opacity:0;transform:translateY(12px) scale(.98)}to{opacity:1;transform:none}}' +
    '.imx .hd{background:#1F3A2E;padding:12px 14px;display:flex;align-items:center;gap:10px}.imx .hd .av{width:40px;height:40px;border-radius:50%;background:#121212;display:grid;place-items:center;flex:none}' +
    '.imx .hd .nm{display:flex;flex-direction:column;flex:1;min-width:0}.imx .hd .nm b{font-size:15px}.imx .hd .nm span{font-size:12px;color:rgba(237,230,214,.72)}' +
    '.imx .hd button{border:0;background:transparent;color:#EDE6D6;width:36px;height:36px;border-radius:10px;cursor:pointer;font-size:20px;line-height:1}.imx .hd button:hover{background:rgba(237,230,214,.1)}' +
    '.imx .log{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px;scroll-behavior:smooth}' +
    '.imx .b{max-width:85%;padding:10px 12px;font-size:14px;line-height:1.5;white-space:pre-line;overflow-wrap:anywhere}' +
    '.imx .bot{align-self:flex-start;background:rgba(237,230,214,.1);border-radius:14px 14px 14px 4px}.imx .me{align-self:flex-end;background:#FF6A1F;color:#121212;border-radius:14px 14px 4px 14px}' +
    '.imx .x{display:block;margin-top:6px;font-size:12.5px;color:rgba(237,230,214,.7)}' +
    '.imx .it{display:flex;flex-direction:column;gap:6px;margin-top:8px}.imx .it a{display:block;text-decoration:none;color:#EDE6D6;background:rgba(237,230,214,.06);border:1px solid rgba(237,230,214,.14);border-radius:10px;padding:8px 10px}.imx .it a:hover{border-color:#FF6A1F}.imx .it b{display:block;font-size:13.5px}.imx .it span{font-size:12px;color:rgba(237,230,214,.7)}' +
    '.imx .acts{display:flex;flex-wrap:wrap;gap:6px;align-self:flex-start;max-width:95%}.imx .acts a{text-decoration:none;border:1px solid rgba(237,230,214,.3);color:#EDE6D6;font-size:12.5px;font-weight:600;padding:6px 11px;border-radius:999px}.imx .acts a:first-child{border-color:#FF6A1F;color:#FF6A1F}.imx .acts a:hover{background:rgba(255,106,31,.12)}' +
    '.imx .dots{display:inline-flex;gap:4px}.imx .dots i{width:6px;height:6px;border-radius:50%;background:rgba(237,230,214,.6);animation:imxD 1s infinite}.imx .dots i:nth-child(2){animation-delay:.15s}.imx .dots i:nth-child(3){animation-delay:.3s}@keyframes imxD{0%,80%,100%{opacity:.3}40%{opacity:1}}' +
    '.imx .sug{display:flex;gap:6px;overflow-x:auto;padding:0 12px 8px;scrollbar-width:none}.imx .sug button{flex:none;border:1px solid rgba(237,230,214,.22);background:transparent;color:#EDE6D6;font:500 12.5px Archivo,system-ui,sans-serif;padding:7px 11px;border-radius:999px;cursor:pointer}.imx .sug button:hover{border-color:#FF6A1F}' +
    '.imx form{margin:0 12px 12px;display:flex;align-items:center;gap:8px;background:rgba(237,230,214,.08);border-radius:12px;padding:6px 6px 6px 12px}.imx input{flex:1;min-width:0;border:0;background:transparent;color:#EDE6D6;font:400 14px Archivo,system-ui,sans-serif;outline:none}.imx input::placeholder{color:rgba(237,230,214,.5)}' +
    '.imx form button{border:0;background:#FF6A1F;width:38px;height:38px;border-radius:9px;display:grid;place-items:center;cursor:pointer}.imx form button:disabled{opacity:.5;cursor:default}' +
    '.imx .ft{font-size:11px;color:rgba(237,230,214,.45);text-align:center;padding:0 12px 10px}' +
    '@media (max-width:480px){#imx{right:16px;bottom:16px}.imx .panel{width:calc(100vw - 32px)}}' +
    '.imx-inline{flex-grow:1;display:flex;min-height:440px}.imx-inline .panel{display:flex!important;position:static;width:100%;max-width:none;height:auto;min-height:440px;box-shadow:none;border:1px solid rgba(237,230,214,.12);border-radius:18px;background:rgba(18,18,18,.35);animation:none}.imx-inline .hd{display:none}.imx-inline .log{max-height:520px}' +
    '@media (prefers-reduced-motion:reduce){.imx .panel,.imx .dots i,.imx .fab{animation:none;transition:none}}' +
    /* l'ancien bouton figé des maquettes est remplacé par celui-ci */
    '.agw,[role=dialog][aria-label="Assistant IMMOTION"]{display:none!important}';

  var LOGO = function (id) { return '<svg width="28" height="28" viewBox="0 0 100 100" aria-hidden="true"><defs><linearGradient id="' + id + '" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#FF6A1F" stop-opacity="0"/><stop offset=".55" stop-color="#FF6A1F" stop-opacity=".55"/><stop offset="1" stop-color="#FF6A1F"/></linearGradient></defs><g transform="translate(50 50) skewX(-12) translate(-50 -50)"><rect x="12" y="33" width="76" height="34" rx="17" fill="none" stroke="url(#' + id + ')" stroke-width="11"/></g></svg>'; };
  var SUGG = ['Un 3 chambres à Strassen ?', 'Prix au m² à Bertrange', 'Estimer une maison de 140 m² à Mamer', 'Louer à Luxembourg', 'Vos honoraires ?', 'Prendre rendez-vous'];

  var root, log, input, sendBtn, sugEl, busy = false;

  function build() {
    var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
    root = document.createElement('div'); root.id = 'imx'; root.className = 'imx';
    root.innerHTML =
      '<div class="panel" role="dialog" aria-label="Conversation avec l’assistant IMMOTION">' +
        '<div class="hd"><span class="av">' + LOGO('imxg1') + '</span><div class="nm"><b>' + esc(CFG.name || 'Assistant IMMOTION') + '</b><span>En ligne · FR · DE · EN</span></div>' +
        '<button type="button" class="new" aria-label="Nouvelle conversation" title="Nouvelle conversation">↺</button><button type="button" class="cls" aria-label="Réduire l\'assistant">×</button></div>' +
        '<div class="log" aria-live="polite"></div>' +
        '<div class="sug"></div>' +
        '<form><label for="imx-in" style="position:absolute;left:-9999px">Votre message</label><input id="imx-in" type="text" autocomplete="off" placeholder="Écrire à l\'assistant" maxlength="500"><button type="submit" aria-label="Envoyer"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#121212" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button></form>' +
        '<div class="ft">' + (CFG.endpoint ? 'Réponses de votre agent IA' : 'Réponses indicatives · un conseiller confirme toujours') + '</div>' +
      '</div>' +
      '<button type="button" class="fab" aria-label="Ouvrir l\'assistant IMMOTION" aria-expanded="false">' + LOGO('imxg2') + '</button>' +
      '<div class="tip"><b>Assistant IMMOTION</b>Un bien, un prix, une commune ? Je réponds tout de suite, en FR, DE ou EN.</div>';
    document.body.appendChild(root);
    log = root.querySelector('.log'); sugEl = root.querySelector('.sug'); input = root.querySelector('input'); sendBtn = root.querySelector('form button');
    root.querySelector('.fab').addEventListener('click', function () { setOpen(!state.open); });
    root.querySelector('.cls').addEventListener('click', function () { setOpen(false); });
    root.querySelector('.new').addEventListener('click', function () { state.msgs = []; save(); render(); input.focus(); });
    root.querySelector('form').addEventListener('submit', function (e) { e.preventDefault(); ask(input.value); });
    var sug = sugEl;
    SUGG.forEach(function (s) { var b = document.createElement('button'); b.type = 'button'; b.textContent = s; b.addEventListener('click', function () { ask(s); }); sug.appendChild(b); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && state.open) setOpen(false); });
    render();
    if (state.open) setOpen(true, true);
  }

  var inline = null, panel = null;
  function mountInline(el) {
    if (!el || el === inline) return;
    inline = el; el.classList.add('imx', 'imx-inline');
    panel = panel || root.querySelector('.panel');
    el.appendChild(panel);
    root.querySelector('.fab').style.display = 'none'; root.querySelector('.tip').style.display = 'none';
    render();
  }
  function watchInline() {
    var find = function () { var el = document.querySelector('#dc-root #imx-inline'); if (el && el !== inline) mountInline(el); };
    new MutationObserver(find).observe(document.body, { childList: true, subtree: true }); find();
  }
  function setOpen(v, silent) {
    if (inline) { if (v && !silent) input.focus(); return; }
    state.open = v; save();
    root.classList.toggle('open', v);
    root.querySelector('.fab').setAttribute('aria-expanded', String(v));
    if (v) { render(); if (!silent) setTimeout(function () { input.focus(); }, 60); }
  }

  function bubble(m) {
    var wrap = document.createDocumentFragment();
    var d = document.createElement('div'); d.className = 'b ' + (m.role === 'user' ? 'me' : 'bot');
    if (m.typing) { d.innerHTML = '<span class="dots" aria-label="L’assistant écrit"><i></i><i></i><i></i></span>'; wrap.appendChild(d); return wrap; }
    d.textContent = m.text;
    if (m.extra) { var x = document.createElement('span'); x.className = 'x'; x.textContent = m.extra; d.appendChild(x); }
    if (m.items && m.items.length) {
      var it = document.createElement('div'); it.className = 'it';
      m.items.forEach(function (i) { var a = document.createElement('a'); a.href = i.href; a.innerHTML = '<b>' + esc(i.title) + '</b><span>' + esc(i.sub) + '</span>'; it.appendChild(a); });
      d.appendChild(it);
    }
    wrap.appendChild(d);
    if (m.actions && m.actions.length) {
      var ac = document.createElement('div'); ac.className = 'acts';
      m.actions.forEach(function (a) { if (!a || !a.href) return; var l = document.createElement('a'); l.href = a.href; l.textContent = a.label || a.href; if (/^https?:/.test(a.href)) { l.target = '_blank'; l.rel = 'noopener'; } ac.appendChild(l); });
      wrap.appendChild(ac);
    }
    return wrap;
  }

  function render(typing) {
    if (!log) return;
    log.innerHTML = '';
    var msgs = state.msgs.length ? state.msgs : [{ role: 'assistant', text: T.fr.hello, actions: [{ label: 'Trouver un bien', href: 'acheter.html' }, { label: 'Estimer', href: 'estimer-bien.html' }, { label: 'Rendez-vous', href: 'rdv-choix.html' }] }];
    msgs.forEach(function (m) { log.appendChild(bubble(m)); });
    if (typing) log.appendChild(bubble({ typing: true }));
    sugEl.style.display = state.msgs.length > 2 ? 'none' : '';
    log.scrollTop = log.scrollHeight;
  }

  function ask(text) {
    text = String(text || '').trim();
    if (!text || busy) return;
    if (!state.open) setOpen(true, true);
    busy = true; sendBtn.disabled = true; input.value = '';
    var history = state.msgs.map(function (m) { return { role: m.role, text: m.text }; });
    state.msgs.push({ role: 'user', text: text }); save(); render(true);
    var started = Date.now();
    var p = CFG.endpoint ? remoteAnswer(text, history) : Promise.resolve(localAnswer(text));
    p.then(function (a) {
      var wait = Math.max(0, (CFG.endpoint ? 0 : 450) - (Date.now() - started));
      setTimeout(function () {
        state.msgs.push({ role: 'assistant', text: a.reply, extra: a.extra, items: a.items, actions: a.actions });
        save(); busy = false; sendBtn.disabled = false; render(); input.focus();
      }, wait);
    });
  }

  /* Les champs « posez votre question » des pages envoient aussi à l'assistant. */
  function hookPageInputs() {
    document.addEventListener('keydown', function (e) {
      var el = e.target;
      if (e.key !== 'Enter' || !el || el.tagName !== 'INPUT' || el.closest('.imx')) return;
      if (/assistant|question|Écri|Ecri|Stellen|Ask|Frage|Schreiben/i.test(el.placeholder || '') && !el.closest('form[data-keep]')) {
        if (el.id === 'msg-in') return; // messagerie de l'espace client
        e.preventDefault(); e.stopPropagation();
        var v = el.value; el.value = ''; ask(v);
      }
    }, true);
    document.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a[aria-label="Envoyer"],button[aria-label="Envoyer"]');
      if (!a || a.closest('.imx')) return;
      var box = a.closest('label,form,div'); var inp = box && box.querySelector('input[type=text]');
      if (!inp || inp.id === 'msg-in') return;
      e.preventDefault(); e.stopPropagation();
      var v = inp.value; inp.value = '';
      if (v.trim()) ask(v); else setOpen(true);
    }, true);
    /* Les liens et boutons qui ouvraient l'ancien assistant ouvrent celui-ci. */
    document.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('button[aria-label^="Ouvrir l\'assistant"],a[href="assistant.html"].open-assistant');
      if (!b || b.closest('.imx')) return;
      e.preventDefault(); e.stopPropagation(); setOpen(true);
    }, true);
  }

  window.IMMOTION_ASK = ask;
  window.IMMOTION_RESET = function () { state.msgs = []; save(); render(); };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { build(); hookPageInputs(); watchInline(); });
  else { build(); hookPageInputs(); watchInline(); }
})();
