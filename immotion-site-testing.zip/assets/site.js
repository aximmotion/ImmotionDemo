/* IMMOTION : pleine largeur, formulaires de maquette et navigation rapide. */
(function () {
  var MIN = 1440, MAX = 1920;

  function rootBox() {
    var host = document.querySelector('#dc-root .sc-host');
    return host && host.firstElementChild;
  }

  /* Pleine largeur : la page occupe toute la fenêtre.
     Entre 1440 et 1920 px elle s'étire ; en dessous elle se réduit, au-dessus elle s'agrandit,
     pour garder les proportions des maquettes. */
  function fit() {
    var w = document.documentElement.clientWidth || window.innerWidth;
    var z = w < MIN ? w / MIN : (w > MAX ? w / MAX : 1);
    document.documentElement.style.zoom = z === 1 ? '' : String(z);
    var r = rootBox();
    if (r && !r.dataset.fluid) {
      r.dataset.fluid = '1';
      r.style.width = '100%';
      r.style.minHeight = '100vh';
      r.style.height = 'auto';
      if (getComputedStyle(r).display === 'grid' && !r.style.gridTemplateRows) r.style.gridTemplateRows = 'minmax(100vh, auto)';
      var bg = getComputedStyle(r).backgroundColor;
      if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') document.body.style.background = bg;
    }
  }

  /* Les formulaires des maquettes n'envoient rien : Entrée suit le bouton principal du formulaire. */
  function follow(f) {
    var links = [].filter.call(f.querySelectorAll('a[href]'), function (a) {
      return !/^(legal|cookies)\.html/.test(a.getAttribute('href'));
    });
    var go = links[links.length - 1];
    if (go) window.location.href = go.getAttribute('href');
  }
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.closest && f.closest('.imx')) return;
    if (!f.getAttribute('action')) { e.preventDefault(); follow(f); }
  }, true);
  document.addEventListener('keydown', function (e) {
    var el = e.target;
    if (e.key !== 'Enter' || el.tagName !== 'INPUT' || /^(checkbox|radio|button|submit)$/.test(el.type)) return;
    if (el.closest('.imx')) return;
    var f = el.form;
    if (f && !f.getAttribute('action')) { e.preventDefault(); follow(f); }
  }, false);

  /* Navigation rapide pour les navigateurs sans « speculation rules » :
     la page visée est préchargée dès que la souris passe sur le lien. */
  var supportsSpec = window.HTMLScriptElement && HTMLScriptElement.supports && HTMLScriptElement.supports('speculationrules');
  if (!supportsSpec) {
    var done = {};
    var pre = function (e) {
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a) return;
      var h = a.getAttribute('href');
      if (!h || /^(https?:|mailto:|tel:|#)/.test(h)) return;
      h = h.split('#')[0];
      if (!h || done[h]) return;
      done[h] = 1;
      var l = document.createElement('link'); l.rel = 'prefetch'; l.href = h; document.head.appendChild(l);
    };
    document.addEventListener('mouseover', pre, { passive: true });
    document.addEventListener('touchstart', pre, { passive: true });
  }

  /* Instantané : la page s'affiche tout de suite (HTML déjà prêt), puis la version interactive prend le relais. */
  var snap = document.getElementById('dc-snap');
  if (snap) {
    var sbg = snap.querySelector('.sc-host > div');
    if (sbg && getComputedStyle(sbg).display === 'grid') sbg.style.gridTemplateRows = 'minmax(100vh, auto)';
    if (sbg) { var c = getComputedStyle(sbg).backgroundColor; if (c && c !== 'rgba(0, 0, 0, 0)') document.body.style.background = c; }
    var mo;
    var swap = function () {
      var h = document.querySelector('#dc-root .sc-host');
      if (snap && h && h.firstElementChild && h.textContent.length > 50) { var y = window.scrollY; snap.remove(); snap = null; if (mo) mo.disconnect(); fit(); if (y) window.scrollTo(0, y); }
    };
    mo = new MutationObserver(swap);
    mo.observe(document.body, { childList: true, subtree: true });
    swap();
  }
  /* Tri des listes de biens (Achat, Location) : réordonne les cartes sans recharger. */
  function num(s) { var m = String(s).replace(/[   ]/g, '').match(/(\d+)€/); return m ? +m[1] : Infinity; }
  function area(s) { var m = String(s).match(/(\d+)\s*m²/); return m ? +m[1] : 0; }
  document.addEventListener('change', function (e) {
    var sel = e.target;
    if (!sel || (sel.id !== 'sb-sort' && sel.id !== 'sl-sort')) return;
    var cards = [].slice.call(document.querySelectorAll('#dc-root article'));
    var mode = sel.value || sel.options[sel.selectedIndex].text;
    var key = function (a, i) {
      var t = a.innerText;
      if (/Prix au m²/.test(mode)) { var p = num(t), s = area(t); return s ? p / s : p; }
      if (/croissant/.test(mode)) return num(t);
      return i;
    };
    cards.map(function (a, i) { return { a: a, k: key(a, i) }; })
      .sort(function (x, y) { return x.k - y.k; })
      .forEach(function (o, i) { o.a.style.order = String(i); });
  });

  window.addEventListener('resize', fit);
  var n = 0, t = setInterval(function () { fit(); if (rootBox() || ++n > 80) { clearInterval(t); fit(); } }, 25);
  fit();
})();
