/* IMMOTION · appli mobile (une seule page, navigation instantanée) */
(function () {
  'use strict';
  var D = window.IMD, CM = D.communes, MAP = D.map;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return [].slice.call((r || document).querySelectorAll(s)); };
  var view = $('#view'), topEl = $('#top'), tabsEl = $('#tabs');

  /* ---------- Outils ---------- */
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fmt(n) { return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' '); }
  function eur(n) { return fmt(n) + ' €'; }
  function meur(n) { return n >= 1e6 ? (Math.round(n / 1e4) / 100).toString().replace('.', ',') + ' M€' : fmt(Math.round(n / 1000)) + ' k€'; }
  function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
  function img(k) { return D.img(k); }
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('imx-' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('imx-' + k, JSON.stringify(v)); } catch (e) {} }
  };
  function vibrate() { try { navigator.vibrate && navigator.vibrate(8); } catch (e) {} }
  function desk(page) { return page + (page.indexOf('?') < 0 ? '?' : '&') + 'desktop=1'; }
  var commune = {}; CM.forEach(function (c) { commune[c.n] = c; });
  function cPrice(c, type) { return /maison/i.test(type) ? c.pm : c.pa; }
  function cEst(c, type) { return /maison/i.test(type) ? c.pme : c.pae; }

  /* ---------- Icônes ---------- */
  var I = {
    home: '<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/>',
    calc: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11h2M12 11h2M16 11h0M8 15h2M12 15h2M8 18h2M12 18h4"/>',
    chat: '<path d="M4 5h16v11H9l-5 4z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 5-6 8-6s6.5 2 8 6"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    back: '<path d="M15 5l-7 7 7 7"/>',
    heart: '<path d="M12 20s-7-4.5-9.2-9C1.4 8 3 4.5 6.5 4.5c2 0 3.5 1.2 5.5 3.2 2-2 3.5-3.2 5.5-3.2C21 4.5 22.6 8 21.2 11 19 15.5 12 20 12 20z"/>',
    map: '<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/>',
    cal: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/>',
    send: '<path d="M4 12l16-8-6 16-2-6z"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    filter: '<path d="M4 6h16M7 12h10M10 18h4"/>',
    share: '<path d="M12 3v13M7 8l5-5 5 5"/><path d="M5 13v7h14v-7"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
    building: '<rect x="5" y="3" width="14" height="18" rx="1"/><path d="M9 7h2M13 7h2M9 11h2M13 11h2M9 15h2M13 15h2"/>',
    house: '<path d="M4 11l8-6 8 6v9H4z"/><path d="M10 20v-5h4v5"/>',
    install: '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 20h14"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a1 1 0 0 1-1 1A16 16 0 0 1 4 5a1 1 0 0 1 1-1z"/>',
    doc: '<path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4M9 12h6M9 16h6"/>',
    spark: '<path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>'
  };
  function ic(n, w, extra) { return '<svg width="' + (w || 22) + '" height="' + (w || 22) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' + (extra || '') + '>' + I[n] + '</svg>'; }
  var WM = '<span class="wm" aria-label="IMMOTION">IMM<span class="pill"></span>TION</span>';

  /* ---------- Favoris ---------- */
  function favs() { return store.get('favs', []); }
  function isFav(k) { return favs().indexOf(k) >= 0; }
  function toggleFav(k) {
    var f = favs(), i = f.indexOf(k);
    if (i >= 0) { f.splice(i, 1); toast('Retiré des favoris'); } else { f.push(k); toast('Ajouté à vos <b>favoris</b>', '#/moi/favoris'); }
    store.set('favs', f); vibrate(); updateBadges(); return i < 0;
  }
  function favBtn(k) { return '<button class="fav" data-fav="' + k + '" aria-pressed="' + isFav(k) + '" aria-label="Favori">' + ic('heart', 20) + '</button>'; }

  /* ---------- Toast et feuilles ---------- */
  var toastT;
  function toast(html, href) {
    var t = $('#toast'); t.innerHTML = '<span class="grow">' + html + '</span>' + (href ? '<a href="' + href + '" class="small" style="color:var(--orange);font-weight:700">Voir</a>' : '');
    t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('on'); }, 2600);
  }
  function sheet(html, dark) {
    var s = $('#sheet'), sc = $('#scrim');
    s.className = 'sheet' + (dark ? ' dark' : ''); s.innerHTML = '<div class="grab"></div>' + html;
    requestAnimationFrame(function () { s.classList.add('on'); sc.classList.add('on'); });
    return s;
  }
  function closeSheet() { $('#sheet').classList.remove('on'); $('#scrim').classList.remove('on'); }
  $('#scrim').addEventListener('click', closeSheet);

  /* ---------- Coque : haut de page et onglets ---------- */
  var TABS = [['', 'Accueil', 'home'], ['biens', 'Biens', 'key'], ['estimer', 'Estimer', 'calc'], ['assistant', 'Assistant', 'chat'], ['moi', 'Mon espace', 'user']];
  function renderTabs(cur) {
    tabsEl.innerHTML = '<nav class="tabs-in" aria-label="Navigation principale">' + TABS.map(function (t) {
      var badge = t[0] === 'moi' && favs().length ? '<span class="dot">' + favs().length + '</span>' : '';
      return '<a class="tab" href="#/' + t[0] + '"' + (cur === t[0] ? ' aria-current="page"' : '') + '>' + ic(t[2], 24) + t[1] + badge + '</a>';
    }).join('') + '</nav>';
  }
  function updateBadges() { renderTabs(curTab); }
  function renderTop(o) {
    var ticker = o.ticker ? '<a class="ticker" href="#/newsletter" aria-label="Infos du marché"><div class="tk">' + D.ticker.concat(D.ticker).map(function (t) { return '<span>' + esc(t) + '<i></i></span>'; }).join('') + '</div></a>' : '';
    topEl.innerHTML = ticker + '<div class="top-in">' +
      (o.back ? '<button class="back" data-back aria-label="Retour">' + ic('back', 24) + '</button><span class="ttl">' + esc(o.title || '') + '</span>'
        : '<a href="#/" aria-label="IMMOTION, accueil">' + WM + '</a><span class="sp"></span>') +
      (o.noRdv || o.back ? '' : '<a class="rdv" href="#/rdv">Rendez-vous</a>') +
      '<button class="icon-btn" data-menu aria-label="Ouvrir le menu">' + ic('menu', 24) + '</button></div>';
  }
  function openMenu() {
    var items = [['#/communes', 'Prix des communes', 'carte des 100 communes'], ['#/biens?m=louer', 'Louer', ''], ['#/gestion', 'Gestion', 'faire gérer son bien'], ['#/offmarket', 'Off-market', ''], ['#/agence', "L'agence", 'équipe et contact'], ['#/rdv', 'Rendez-vous', ''], ['#/honoraires', 'Honoraires', ''], ['#/faq', 'Questions fréquentes', ''], ['#/newsletter', 'Newsletter', '']];
    sheet('<nav class="menu-list">' + items.map(function (i) { return '<a href="' + i[0] + '">' + i[1] + (i[2] ? ' <small>' + i[2] + '</small>' : '') + '</a>'; }).join('') + '</nav>' +
      '<div class="stack" style="margin-top:18px">' + installCard(true) +
      '<div class="row small" style="justify-content:space-between;color:var(--cr-2)"><a href="' + desk('index.html') + '">Version ordinateur</a><a href="' + desk('legal.html') + '">Mentions légales</a><a href="' + desk('cookies.html') + '">Cookies</a></div></div>', true);
  }
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-menu]'); if (t) { openMenu(); return; }
    t = e.target.closest('[data-back]'); if (t) { goBack(); return; }
    t = e.target.closest('[data-fav]'); if (t) { e.preventDefault(); e.stopPropagation(); t.setAttribute('aria-pressed', toggleFav(t.dataset.fav)); return; }
    t = e.target.closest('#sheet a[href^="#"]'); if (t) closeSheet();
    t = e.target.closest('[data-install]'); if (t) { e.preventDefault(); doInstall(); }
  });

  /* ---------- Installation (appli) ---------- */
  var deferred = null;
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; $$('[data-install-card]').forEach(function (el) { el.hidden = false; }); });
  function isStandalone() { return window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true; }
  function isIOS() { return /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1); }
  function installCard(dark) {
    if (isStandalone()) return '';
    var show = deferred || isIOS();
    return '<a href="#" class="install" data-install data-install-card' + (show ? '' : ' hidden') + '><span class="ic">' + ic('install', 22, ' style="color:var(--orange)"') + '</span><span class="grow"><b>Installer l’appli IMMOTION</b><br><span class="small" style="color:var(--cr-2)">Sur votre écran d’accueil, en plein écran.</span></span>' + ic('arrow', 20) + '</a>';
  }
  function doInstall() {
    if (deferred) { deferred.prompt(); deferred.userChoice.then(function (r) { if (r.outcome === 'accepted') toast('Appli <b>installée</b>'); deferred = null; }); return; }
    sheet('<h3 class="disp" style="font-size:26px">Installer sur iPhone</h3><ol class="stack" style="padding-left:20px;margin:0 0 18px"><li>Touchez le bouton <b>Partager</b> en bas de Safari.</li><li>Choisissez <b>Sur l’écran d’accueil</b>.</li><li>Touchez <b>Ajouter</b> : l’icône IMMOTION apparaît avec vos applis.</li></ol><button class="btn or block" onclick="document.getElementById(\'scrim\').click()">Compris</button>', true);
  }

  /* ---------- Cartes ---------- */
  function vsMarket(b) {
    var c = commune[b.c]; if (!c) return null;
    var avg = cPrice(c, b.type), pm2 = b.prix / b.m2, d = Math.round((pm2 / avg - 1) * 100);
    return { pm2: pm2, avg: avg, d: d, txt: Math.abs(d) <= 2 ? 'dans la moyenne' : (d < 0 ? Math.abs(d) + ' % sous la moyenne' : d + ' % au-dessus') };
  }
  function saleCard(b, wide) {
    var v = vsMarket(b);
    return '<a class="pcard" href="#/bien/' + b.id + '"><div class="ph"><img src="' + img(b.img) + '" alt="' + esc(b.alt) + '" loading="lazy">' +
      (b.tag ? '<div class="tags"><span class="tag' + (b.tag === 'Visite 3D' ? ' ink' : '') + '">' + b.tag + '</span></div>' : '') + favBtn('b' + b.id) + '</div>' +
      '<div class="body"><span class="loc">' + b.type + ' · ' + esc(b.c) + '</span><span class="t">' + esc(b.t) + '</span><span class="meta">' + b.m2 + ' m² · ' + b.ch + ' ch. · ' + b.sdb + ' sdb · Classe ' + b.cl + '</span>' +
      '<div class="pr"><span class="price">' + eur(b.prix) + '</span>' + (v ? '<span class="vs' + (v.d < -2 ? ' good' : '') + '">' + fmt(v.pm2) + ' €/m² · ' + v.txt + '</span>' : '') + '</div></div></a>';
  }
  function rentCard(b) {
    return '<a class="pcard" href="#/location/' + b.id + '"><div class="ph"><img src="' + img(b.img) + '" alt="' + esc(b.alt) + '" loading="lazy"><div class="tags"><span class="tag cr">Disponible ' + b.dispo + '</span>' + (b.meuble ? '<span class="tag ink">Meublé</span>' : '') + '</div>' + favBtn('l' + b.id) + '</div>' +
      '<div class="body"><span class="loc">' + b.type + ' · ' + esc(b.c) + '</span><span class="t">' + esc(b.t) + '</span><span class="meta">' + b.m2 + ' m²' + (b.ch ? ' · ' + b.ch + ' ch.' : '') + (b.cl ? ' · Classe ' + b.cl : '') + '</span>' +
      '<div class="pr"><span class="price">' + eur(b.loyer) + '<span class="small muted" style="font-weight:500"> / mois</span></span><span class="vs">' + (b.charges ? '+ ' + eur(b.charges) + ' de charges' : 'charges selon conso.') + '</span></div></div></a>';
  }

  /* ---------- Carte des communes (SVG) ---------- */
  function colorScale(vals) {
    var s = vals.slice().sort(function (a, b) { return a - b; });
    return function (v) {
      var i = 0; while (i < s.length && s[i] < v) i++;
      var t = i / (s.length - 1 || 1);
      var a = [44, 74, 60], b = [255, 106, 31], c = [237, 230, 214];
      var col = t < .7 ? mix(a, b, t / .7) : mix(b, c, (t - .7) / .3 * .55);
      return 'rgb(' + col.join(',') + ')';
    };
    function mix(x, y, k) { return x.map(function (v, j) { return Math.round(v + (y[j] - v) * k); }); }
  }
  function mapSVG(o) {
    o = o || {}; var key = o.key || 'pa';
    var scale = colorScale(CM.map(function (c) { return c[key]; }));
    var paths = CM.map(function (c) {
      var est = c[key === 'pa' ? 'pae' : 'pme'];
      return '<path d="' + MAP.p[c.id] + '" fill="' + scale(c[key]) + '"' + (est ? ' fill-opacity=".62"' : '') + ' data-c="' + esc(c.n) + '"' + (o.sel === c.n ? ' class="sel"' : '') + '><title>' + esc(c.n) + '</title></path>';
    }).join('');
    var sel = o.sel && commune[o.sel] ? (function () { var c = commune[o.sel]; var p = MAP.c[c.id]; return '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="5" fill="var(--cream)" stroke="var(--ink)" stroke-width="2"/>'; })() : '';
    var pins = (o.pins || []).map(function (pn) { var c = commune[pn.c]; if (!c) return ''; var p = MAP.c[c.id]; return '<g data-go="' + pn.href + '" style="cursor:pointer"><circle class="pin" cx="' + p[0] + '" cy="' + (p[1] - 2) + '" r="' + (pn.r || 9) + '"/><text class="pin-t" x="' + p[0] + '" y="' + (p[1] + 1.2) + '" text-anchor="middle">' + pn.l + '</text></g>'; }).join('');
    return '<svg viewBox="-4 -4 ' + (MAP.w + 8) + ' ' + (MAP.h + 8) + '" role="img" aria-label="Carte des 100 communes du Luxembourg">' + paths + sel + pins + '</svg>';
  }

  /* ---------- Graphique d'évolution ---------- */
  function lineChart(c) {
    var W = 340, H = 170, L = 38, R = 12, T = 12, B = 22;
    var sa = c.sa || [], sm = c.sm || [];
    var all = sa.concat(sm); if (!all.length) return '<p class="small muted">Pas de série publiée pour cette commune.</p>';
    var y0 = Math.min.apply(null, all.map(function (d) { return d[1]; })), y1 = Math.max.apply(null, all.map(function (d) { return d[1]; }));
    var step = y1 - y0 > 6000 ? 2000 : 1000; y0 = Math.floor(y0 / step) * step; y1 = Math.ceil(y1 / step) * step;
    var x0 = 2010, x1 = 2025;
    var X = function (x) { return L + (x - x0) / (x1 - x0) * (W - L - R); }, Y = function (y) { return T + (1 - (y - y0) / (y1 - y0)) * (H - T - B); };
    var grid = '';
    for (var v = y0; v <= y1; v += step) grid += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + Y(v) + '" y2="' + Y(v) + '" stroke="rgba(237,230,214,.1)"/><text x="' + (L - 6) + '" y="' + (Y(v) + 3.5) + '" text-anchor="end" font-size="9.5" fill="rgba(237,230,214,.55)">' + fmt(v / 1000) + ' k</text>';
    [2010, 2015, 2020, 2025].forEach(function (yr) { grid += '<text x="' + X(yr) + '" y="' + (H - 6) + '" text-anchor="middle" font-size="9.5" fill="rgba(237,230,214,.55)">' + yr + '</text>'; });
    function line(s, col) {
      if (!s.length) return '';
      var d = s.map(function (p, i) { return (i ? 'L' : 'M') + X(p[0]).toFixed(1) + ',' + Y(p[1]).toFixed(1); }).join('');
      var l = s[s.length - 1];
      return '<path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="2.4" stroke-linejoin="round"/><circle cx="' + X(l[0]) + '" cy="' + Y(l[1]) + '" r="4" fill="' + col + '"/>';
    }
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Évolution des prix annoncés au m², 2010 à 2025">' + grid + line(sm, '#EDE6D6') + line(sa, '#FF6A1F') + '</svg>' +
      '<div class="row tiny" style="gap:16px;color:var(--cr-2)"><span class="row" style="gap:6px"><i style="width:14px;height:3px;background:var(--orange);display:inline-block;border-radius:2px"></i>Appartements</span><span class="row" style="gap:6px"><i style="width:14px;height:3px;background:var(--cream);display:inline-block;border-radius:2px"></i>Maisons</span><span>€/m² annoncés</span></div>';
  }
  function growth(s, from) { if (!s || !s.length) return null; var a = s.filter(function (d) { return d[0] === from; })[0], b = s[s.length - 1]; return a ? Math.round((b[1] / a[1] - 1) * 100) : null; }

  /* ================= Écrans ================= */
  var S = {};

  /* ----- Accueil ----- */
  S[''] = function () {
    renderTop({ ticker: true });
    var top5 = CM.slice().sort(function (a, b) { return b.pa - a.pa; }).slice(0, 5);
    var mx = top5[0].pa;
    var nextRdv = store.get('rdvs', []).filter(function (r) { return r.ts > Date.now(); })[0];
    return '<section class="hero dark"><span class="blob" style="width:260px;height:200px;right:-80px;top:-40px;background:var(--orange)"></span><span class="blob" style="width:220px;height:180px;left:-90px;bottom:-60px;background:var(--forest)"></span>' +
      '<span class="eyebrow">Agence immobilière · Luxembourg · 100 communes</span><h1 class="disp">On bouge.<br><em>Vous emménagez.</em></h1><p>Acheter, vendre, louer, faire gérer : une agence qui va vite, avec les vrais chiffres du marché.</p>' +
      '<form class="search" id="hs"><div class="seg" role="group" aria-label="Projet"><button type="button" data-m="acheter" aria-pressed="true">Acheter</button><button type="button" data-m="louer" aria-pressed="false">Louer</button></div>' +
      '<label class="field" style="color:var(--cr-2)">Commune<input class="input" id="hs-c" list="dl-communes" placeholder="Strassen, Bertrange…" autocomplete="off"></label>' +
      '<div class="grid2"><label class="field" style="color:var(--cr-2)">Type<select class="input" id="hs-t"><option value="">Tous</option><option>Appartement</option><option>Maison</option></select></label><label class="field" style="color:var(--cr-2)">Budget max.<select class="input" id="hs-b"><option value="">Sans limite</option></select></label></div>' +
      '<button class="btn or block" type="submit">' + ic('search', 20) + 'Rechercher</button></form></section>' +
      (nextRdv ? '<a href="#/moi" class="sec" style="display:block;padding-bottom:0"><div class="card row" style="padding:14px;background:var(--ink);color:var(--cream)"><span class="tag">' + ic('cal', 14) + '</span><span class="grow"><span class="tiny" style="color:var(--cr-2)">Votre prochain rendez-vous</span><br><b>' + esc(nextRdv.label) + '</b></span>' + ic('arrow', 20) + '</div></a>' : '') +
      '<nav class="quick" aria-label="Raccourcis"><a href="#/estimer"><span class="qi">' + ic('calc', 26) + '</span>Estimer mon bien</a><a href="#/communes"><span class="qi" style="color:var(--orange)">' + ic('map', 26) + '</span>Prix des communes</a><a href="#/rdv"><span class="qi">' + ic('cal', 26) + '</span>Rendez-vous</a><a href="#/offmarket"><span class="qi">' + ic('lock', 26) + '</span>Off-market</a></nav>' +
      '<section class="sec"><div class="sec-h"><h2 class="disp">À la une</h2><a class="more" href="#/biens">Tout voir</a></div><div class="rail">' + D.sale.slice(0, 4).map(function (b) { return saleCard(b); }).join('') + '</div></section>' +
      '<section class="sec" style="padding-top:0"><a href="#/estimer" class="forest card" style="display:block;padding:20px;border-radius:22px"><span class="eyebrow">Propriétaire ?</span><h2 class="disp" style="font-size:28px;margin:8px 0">Combien vaut <em>votre bien ?</em></h2><p class="muted" style="margin:0 0 14px">Une première fourchette en 2 minutes, à partir des prix officiels de votre commune.</p><span class="btn or">Estimer gratuitement ' + ic('arrow', 18) + '</span></a></section>' +
      '<section class="sec dark"><span class="eyebrow">Carte des 100 communes</span><div class="sec-h" style="margin-top:8px"><h2 class="disp">Le prix au m², <em>commune par commune.</em></h2></div>' +
      '<div class="stack" style="gap:2px;margin-bottom:16px">' + top5.map(function (c) { return '<a class="row" href="#/commune/' + encodeURIComponent(c.n) + '" style="padding:9px 0;border-bottom:1px solid var(--cr-line)"><span style="width:118px" class="small">' + esc(c.n) + '</span><span class="grow" style="height:6px;border-radius:3px;background:rgba(237,230,214,.08)"><i style="display:block;height:100%;width:' + (c.pa / mx * 100) + '%;background:var(--orange);border-radius:3px"></i></span><b class="num small" style="width:74px;text-align:right">' + fmt(c.pa) + ' €</b></a>'; }).join('') + '</div>' +
      '<p class="tiny muted" style="margin:0 0 14px">Appartements, prix annoncés des 12 derniers mois. Source : Observatoire de l’Habitat.</p><a class="btn ghost block" href="#/communes" style="color:var(--cream)">' + ic('map', 20) + 'Explorer la carte</a></section>' +
      '<section class="sec"><div class="sec-h"><h2 class="disp">Louer</h2><a class="more" href="#/biens?m=louer">Tout voir</a></div><div class="rail">' + D.rent.slice(0, 4).map(rentCard).join('') + '</div></section>' +
      '<section class="sec" style="padding-top:0"><div class="stack"><a href="#/gestion" class="card row" style="padding:16px"><span class="qi" style="width:48px;height:48px;border-radius:14px;background:var(--ink);color:var(--orange);display:grid;place-items:center">' + ic('key', 24) + '</span><span class="grow"><b>Vous avez un bien à louer ?</b><br><span class="small muted">Gestion dès 4 % HTVA des loyers encaissés.</span></span>' + ic('arrow', 20) + '</a>' +
      '<a href="#/offmarket" class="card row" style="padding:16px;background:var(--ink);color:var(--cream)"><span style="width:48px;height:48px;border-radius:14px;overflow:hidden;flex:none"><img src="' + img('fff76aeb') + '" alt="" style="width:100%;height:100%;object-fit:cover"></span><span class="grow"><b>Off-market</b><br><span class="small muted">Des biens qu’on ne voit nulle part ailleurs.</span></span>' + ic('arrow', 20) + '</a>' +
      '<a href="#/newsletter" class="card" style="padding:18px;background:var(--orange);display:block"><b style="font-size:18px">La newsletter du marché</b><br><span class="small">Chaque mois, les chiffres vérifiés. Une lettre, désinscription en un clic.</span></a>' +
      installCard() + '</div></section>' + footer();
  };
  S[''].after = function () {
    var m = 'acheter', bsel = $('#hs-b');
    function budgets() { var o = m === 'acheter' ? [600000, 900000, 1100000, 1500000] : [1000, 2000, 3000, 5000]; bsel.innerHTML = '<option value="">Sans limite</option>' + o.map(function (v) { return '<option value="' + v + '">' + eur(v) + '</option>'; }).join(''); }
    budgets();
    $$('#hs .seg button').forEach(function (b) { b.onclick = function () { m = b.dataset.m; $$('#hs .seg button').forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); budgets(); }; });
    $('#hs').onsubmit = function (e) {
      e.preventDefault();
      var q = { m: m, c: matchCommune($('#hs-c').value), t: $('#hs-t').value, b: bsel.value };
      store.set('filters-' + m, { c: q.c || '', t: q.t, b: q.b ? +q.b : null, ch: null });
      go('#/biens?m=' + m);
    };
  };
  function matchCommune(v) { v = norm(v).trim(); if (!v) return ''; var hit = CM.filter(function (c) { return norm(c.n) === v; })[0] || CM.filter(function (c) { return norm(c.n).indexOf(v) === 0; })[0]; return hit ? hit.n : ''; }

  function footer() {
    return '<footer class="foot">' + WM.replace('class="wm"', 'class="wm" style="font-size:22px;color:var(--cream)"') + '<span>L’immobilier au Luxembourg, en mouvement.</span><div class="links"><a href="#/agence">L’agence</a><a href="#/faq">FAQ</a><a href="#/honoraires">Honoraires</a><a href="' + desk('legal.html') + '">Mentions légales</a><a href="' + desk('cookies.html') + '">Cookies</a><a href="' + desk('index.html') + '">Version ordinateur</a></div></footer>';
  }

  /* ----- Biens (achat / location) ----- */
  S.biens = function (p, q) {
    var m = q.m === 'louer' ? 'louer' : 'acheter';
    renderTop({});
    var f = store.get('filters-' + m, { c: '', t: '', b: null, ch: null });
    var srt = store.get('sort-' + m, 'rec');
    var src = m === 'acheter' ? D.sale : D.rent, price = function (b) { return m === 'acheter' ? b.prix : b.loyer; };
    var res = src.filter(function (b) {
      return (!f.c || b.c === f.c) && (!f.t || b.type === f.t || (f.t === 'Appartement' && b.type === 'Studio')) && (!f.b || price(b) <= f.b) && (!f.ch || b.ch >= f.ch);
    });
    if (srt === 'prix') res.sort(function (a, b) { return price(a) - price(b); });
    if (srt === 'm2') res.sort(function (a, b) { return price(a) / a.m2 - price(b) / b.m2; });
    var asMap = q.v === 'carte';
    var chip = function (k, label, on) { return '<button class="chip" data-f="' + k + '" aria-pressed="' + !!on + '">' + label + '</button>'; };
    return '<section class="sec dark" style="padding-bottom:18px"><div class="seg" role="group" aria-label="Acheter ou louer"><a class="btn" style="flex:1;min-height:42px;border-radius:11px;font-size:14.5px;' + (m === 'acheter' ? 'background:var(--orange);color:var(--ink)' : 'background:transparent;color:var(--cr-2)') + '" href="#/biens?m=acheter">Acheter</a><a class="btn" style="flex:1;min-height:42px;border-radius:11px;font-size:14.5px;' + (m === 'louer' ? 'background:var(--orange);color:var(--ink)' : 'background:transparent;color:var(--cr-2)') + '" href="#/biens?m=louer">Louer</a></div>' +
      '<h1 class="disp" style="font-size:38px;margin:18px 0 4px">' + (m === 'acheter' ? 'Biens à vendre' : 'Biens à louer') + '</h1><div class="row small muted"><span>' + res.length + ' bien' + (res.length > 1 ? 's' : '') + '</span><span class="demo">Exemples de la maquette</span></div></section>' +
      '<div style="position:sticky;top:calc(var(--head) + var(--top));z-index:20;background:var(--cream);padding:12px 16px;border-bottom:1px solid var(--line)"><div class="chips">' +
      chip('all', ic('filter', 16) + 'Filtres', f.c || f.t || f.b || f.ch) + chip('c', f.c || 'Commune', f.c) + chip('t', f.t || 'Type', f.t) + chip('b', f.b ? '≤ ' + (m === 'acheter' ? meur(f.b) : eur(f.b)) : 'Budget', f.b) + chip('ch', f.ch ? f.ch + ' ch. et +' : 'Chambres', f.ch) + '</div>' +
      '<div class="row" style="margin-top:10px;justify-content:space-between"><label class="row small muted">Trier<select id="srt" class="chip" style="min-height:34px;padding:4px 10px"><option value="rec"' + (srt === 'rec' ? ' selected' : '') + '>Plus récents</option><option value="prix"' + (srt === 'prix' ? ' selected' : '') + '>' + (m === 'acheter' ? 'Prix croissant' : 'Loyer croissant') + '</option><option value="m2"' + (srt === 'm2' ? ' selected' : '') + '>Prix au m²</option></select></label>' +
      '<a class="chip" style="min-height:34px;padding:4px 12px" href="#/biens?m=' + m + (asMap ? '' : '&v=carte') + '">' + ic(asMap ? 'filter' : 'map', 16) + (asMap ? 'Liste' : 'Carte') + '</a></div></div>' +
      (asMap ? '<section class="sec"><div class="map-wrap">' + mapSVG({ pins: res.map(function (b, i) { return { c: b.c, l: i + 1, href: (m === 'acheter' ? '#/bien/' : '#/location/') + b.id }; }) }) + '</div><p class="tiny muted">Touchez un repère pour ouvrir le bien.</p><div class="list">' + res.map(function (b, i) { return '<a class="row card" style="padding:8px" href="' + (m === 'acheter' ? '#/bien/' : '#/location/') + b.id + '"><span class="tag" style="min-width:24px;text-align:center">' + (i + 1) + '</span><img src="' + img(b.img) + '" alt="" style="width:64px;height:48px;border-radius:9px;object-fit:cover"><span class="grow small"><b>' + esc(b.t) + '</b><br>' + esc(b.c) + ' · ' + eur(price(b)) + (m === 'louer' ? ' / mois' : '') + '</span></a>'; }).join('') + '</div></section>'
        : '<section class="sec"><div class="list">' + (res.length ? res.map(m === 'acheter' ? saleCard : rentCard).join('') : '<div class="empty"><div class="ei">' + ic('search', 28) + '</div><b>Aucun bien ne correspond</b><p class="small">Élargissez vos critères ou créez une alerte : vous serez prévenu dès qu’un bien arrive.</p></div>') + '</div>' +
          '<div class="stack" style="margin-top:18px"><button class="btn block" id="alert">' + ic('bell', 20) + 'Créer une alerte avec ces critères</button><a class="btn ghost block" href="#/offmarket">' + ic('lock', 20) + 'Voir aussi l’off-market</a></div></section>');
  };
  S.biens.after = function (p, q) {
    var m = q.m === 'louer' ? 'louer' : 'acheter';
    var f = store.get('filters-' + m, { c: '', t: '', b: null, ch: null });
    var srt = $('#srt'); if (srt) srt.onchange = function () { store.set('sort-' + m, srt.value); rerender(); };
    var al = $('#alert'); if (al) al.onclick = function () {
      var a = store.get('alerts', []); a.push({ m: m, f: f, d: Date.now() }); store.set('alerts', a);
      toast('Alerte créée : vous serez <b>prévenu</b>', '#/moi'); vibrate();
    };
    $$('[data-f]').forEach(function (b) { b.onclick = function () { filterSheet(m, f, b.dataset.f); }; });
  };
  function filterSheet(m, f, focus) {
    var types = m === 'acheter' ? ['Appartement', 'Maison'] : ['Appartement', 'Maison', 'Colocation'];
    var bud = m === 'acheter' ? [600000, 900000, 1100000, 1500000] : [1000, 1500, 2000, 3000, 5000];
    var cs = (m === 'acheter' ? D.sale : D.rent).map(function (b) { return b.c; }).filter(function (v, i, a) { return a.indexOf(v) === i; });
    var g = function (k, arr, lab, cur) { return '<div class="stack" style="gap:8px;margin-bottom:18px"><b>' + lab + '</b><div class="row" style="flex-wrap:wrap;gap:8px">' + '<button class="chip" data-k="' + k + '" data-v="" aria-pressed="' + !cur + '">Tous</button>' + arr.map(function (v) { var val = typeof v === 'number' ? v : v; return '<button class="chip" data-k="' + k + '" data-v="' + val + '" aria-pressed="' + (String(cur) === String(val)) + '">' + (k === 'b' ? '≤ ' + (m === 'acheter' ? meur(v) : eur(v)) : k === 'ch' ? v + ' et +' : esc(v)) + '</button>'; }).join('') + '</div></div>'; };
    var s = sheet('<h3 class="disp" style="font-size:26px">Filtres</h3>' + g('c', cs, 'Commune', f.c) + g('t', types, 'Type de bien', f.t) + g('b', bud, m === 'acheter' ? 'Budget maximum' : 'Loyer maximum', f.b) + g('ch', [1, 2, 3, 4], 'Chambres', f.ch) +
      '<div class="row"><button class="btn ghost" id="fr">Effacer</button><button class="btn or grow" id="fa">Voir les biens</button></div>');
    var nf = JSON.parse(JSON.stringify(f));
    $$('[data-k]', s).forEach(function (b) { b.onclick = function () { var k = b.dataset.k, v = b.dataset.v; nf[k] = v === '' ? (k === 'c' || k === 't' ? '' : null) : (k === 'b' || k === 'ch' ? +v : v); $$('[data-k="' + k + '"]', s).forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); }; });
    $('#fr', s).onclick = function () { store.set('filters-' + m, { c: '', t: '', b: null, ch: null }); closeSheet(); rerender(); };
    $('#fa', s).onclick = function () { store.set('filters-' + m, nf); closeSheet(); rerender(); };
  }

  /* ----- Fiche d'un bien à vendre ----- */
  S.bien = function (p) {
    var b = D.sale.filter(function (x) { return x.id === +p[0]; })[0]; if (!b) return notFound();
    renderTop({ back: true, title: b.t });
    var c = commune[b.c], v = vsMarket(b), adv = D.advisors.filter(function (a) { return a.id === b.adv; })[0];
    var dpe = ['A+', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'], dcol = ['#1F3A2E', '#2E5A3F', '#4C7A4A', '#8A9A3E', '#C9A227', '#E08A1E', '#FF6A1F', '#E0501A', '#B83A16', '#8A2A12'];
    var vv = c && c.v;
    return '<div class="gal"><img src="' + img(b.img) + '" alt="' + esc(b.alt) + '">' + favBtn('b' + b.id) + '<div class="tags">' + (b.tag ? '<span class="tag">' + b.tag + '</span>' : '') + '<span class="tag cr">Bien d’exemple</span></div></div>' +
      '<section class="sec stack" style="gap:6px"><span class="small muted">' + b.type + ' · ' + esc(b.c) + (c ? ' · canton ' + esc(c.ct) : '') + '</span><h1 class="disp" style="font-size:34px">' + esc(b.t) + '</h1>' +
      '<div class="row" style="align-items:baseline;justify-content:space-between;margin-top:6px"><span class="big">' + eur(b.prix) + '</span>' + (v ? '<span class="small muted num">' + fmt(v.pm2) + ' €/m²</span>' : '') + '</div>' +
      '<div class="row" style="flex-wrap:wrap;gap:6px;margin-top:8px">' + b.feat.map(function (x) { return '<span class="chip" style="min-height:32px;padding:5px 11px;font-size:13px">' + esc(x) + '</span>'; }).join('') + '</div></section>' +
      '<section class="sec" style="padding-top:0"><div class="facts"><div><span>Surface</span><b>' + b.m2 + ' m²</b></div><div><span>Chambres</span><b>' + b.ch + '</b></div><div><span>Salles de bain</span><b>' + b.sdb + '</b></div><div><span>Classe énergie</span><b>' + b.cl + '</b></div></div>' +
      '<p class="muted" style="margin:16px 0 0">' + esc(b.type) + ' de ' + b.m2 + ' m² à ' + esc(b.c) + ', ' + b.ch + ' chambre' + (b.ch > 1 ? 's' : '') + ' et ' + b.sdb + ' salle' + (b.sdb > 1 ? 's' : '') + ' de bain, classe énergétique ' + b.cl + '. La description complète, les plans et la visite sont présentés par votre conseiller.</p></section>' +
      '<section class="sec" style="padding-top:0"><div class="card" style="padding:16px"><b>Passeport énergétique</b><div class="dpe" style="margin-top:14px">' + dpe.map(function (k, i) { return '<span style="background:' + dcol[i] + '"' + (k === b.cl ? ' class="on"' : '') + '>' + k + '</span>'; }).join('') + '</div><p class="tiny muted" style="margin:10px 0 0">Performance énergétique, de A+ à I.</p></div></section>' +
      (v ? '<section class="sec dark"><span class="eyebrow">Face au marché</span><h2 class="disp" style="font-size:26px;margin:8px 0 14px">' + (Math.abs(v.d) <= 2 ? 'Au prix du marché' : v.d < 0 ? '<em>' + Math.abs(v.d) + ' %</em> sous la moyenne' : '<em>' + v.d + ' %</em> au-dessus') + '</h2>' +
        '<div class="kv"><span>Ce bien</span><b style="color:var(--orange)">' + fmt(v.pm2) + ' €/m²</b></div><div class="kv"><span>' + (/maison/i.test(b.type) ? 'Maisons' : 'Appartements') + ' à ' + esc(b.c) + '</span><b>' + (cEst(c, b.type) ? '≈ ' : '') + fmt(v.avg) + ' €/m²</b></div><div class="kv"><span>Luxembourg-Ville (appartements)</span><b>' + fmt(commune.Luxembourg.pa) + ' €/m²</b></div>' +
        '<p class="tiny muted" style="margin:10px 0 0">Prix annoncés des 12 derniers mois. Source : Observatoire de l’Habitat.</p></section>' : '') +
      '<section class="sec"><h2 class="disp" style="font-size:26px;margin-bottom:14px">Vos mensualités</h2><div class="card stack" style="padding:16px;gap:14px">' +
      '<label class="field">Apport <span class="row" style="justify-content:space-between"><input type="range" id="sim-a" min="0" max="' + Math.round(b.prix * 0.6 / 10000) * 10000 + '" step="10000" value="' + Math.round(b.prix * 0.2 / 10000) * 10000 + '"><b class="num" id="sim-av" style="color:var(--ink);min-width:90px;text-align:right"></b></span></label>' +
      '<label class="field">Taux <span class="row" style="justify-content:space-between"><input type="range" id="sim-t" min="1.5" max="5" step="0.01" value="3.19"><b class="num" id="sim-tv" style="color:var(--ink);min-width:90px;text-align:right"></b></span></label>' +
      '<div class="seg" id="sim-d"><button aria-pressed="false" data-y="20">20 ans</button><button aria-pressed="true" data-y="25">25 ans</button><button aria-pressed="false" data-y="30">30 ans</button></div>' +
      '<div class="row" style="background:var(--ink);color:var(--cream);border-radius:14px;padding:14px 16px;justify-content:space-between"><span>Mensualité estimée</span><b class="num" id="sim-m" style="font-size:26px;color:var(--orange)"></b></div>' +
      '<p class="tiny muted" style="margin:0">Indicatif, hors assurance. Taux variable moyen : 3,19 % en juin 2026 (BCL).</p></div></section>' +
      '<section class="sec" style="padding-top:0"><h2 class="disp" style="font-size:26px;margin-bottom:14px">Frais d’achat</h2><div class="card" style="padding:16px"><div class="seg" id="fr-n" style="margin-bottom:10px"><button aria-pressed="false" data-n="1">J’achète seul</button><button aria-pressed="true" data-n="2">À deux</button></div>' +
      '<div class="kv"><span>Droits d’enregistrement et de transcription (7 %)</span><b>' + eur(b.prix * 0.07) + '</b></div><div class="kv"><span>Bëllegen Akt, résidence principale</span><b id="fr-ba" style="color:var(--forest)"></b></div><div class="kv"><span>Reste à payer</span><b id="fr-r"></b></div>' +
      '<p class="tiny muted" style="margin:10px 0 0">40 000 € de crédit d’impôt par acheteur, pour votre résidence principale. Hors émoluments du notaire et frais de prêt.</p></div></section>' +
      (vv ? '<section class="sec" style="padding-top:0"><div class="sec-h"><h2 class="disp" style="font-size:26px">Vivre à ' + esc(b.c) + '</h2><a class="more" href="#/commune/' + encodeURIComponent(b.c) + '">La commune</a></div><div class="grid2">' +
        [[vv.creche, 'crèches et maisons relais'], [vv.ecole, 'écoles fondamentales'], [vv.commerce + vv.resto, 'commerces, restos, cafés'], [vv.bus + vv.train + vv.tram, 'arrêts de bus, train, tram']].map(function (t) { return '<div class="tile"><b>' + fmt(t[0]) + '</b><span>' + t[1] + '</span></div>'; }).join('') + '</div><p class="tiny muted">Équipements dans la commune, OpenStreetMap, septembre 2026. Ordres de grandeur.</p></section>' : '') +
      (adv ? '<section class="sec" style="padding-top:0"><a class="card adv" style="padding:14px" href="#/conseiller/' + adv.id + '"><img src="' + img(adv.av) + '" alt=""><span class="grow"><span class="n">' + adv.n + '</span><br><span class="small muted">' + adv.short + ' · ' + adv.langs.join(' · ') + '</span></span>' + ic('arrow', 20) + '</a></section>' : '') +
      '<div style="height:70px"></div><div class="cta-bar"><button class="btn ghost" id="share" aria-label="Partager">' + ic('share', 20) + '</button><a class="btn or" href="#/rdv?adv=' + b.adv + '&bien=' + b.id + '">Réserver une visite</a></div>';
  };
  S.bien.after = function (p) {
    var b = D.sale.filter(function (x) { return x.id === +p[0]; })[0]; if (!b) return;
    var yrs = 25, n = 2;
    function sim() {
      var a = +$('#sim-a').value, t = +$('#sim-t').value, E = Math.max(0, b.prix - a), r = t / 1200, k = yrs * 12;
      var M = r ? E * r / (1 - Math.pow(1 + r, -k)) : E / k;
      $('#sim-av').textContent = eur(a); $('#sim-tv').textContent = t.toFixed(2).replace('.', ',') + ' %'; $('#sim-m').textContent = eur(M);
    }
    function fr() { var droits = b.prix * 0.07, ba = Math.min(droits, 40000 * n); $('#fr-ba').textContent = '− ' + eur(ba); $('#fr-r').textContent = eur(droits - ba); }
    $('#sim-a').oninput = sim; $('#sim-t').oninput = sim;
    $$('#sim-d button').forEach(function (x) { x.onclick = function () { yrs = +x.dataset.y; $$('#sim-d button').forEach(function (y) { y.setAttribute('aria-pressed', y === x); }); sim(); }; });
    $$('#fr-n button').forEach(function (x) { x.onclick = function () { n = +x.dataset.n; $$('#fr-n button').forEach(function (y) { y.setAttribute('aria-pressed', y === x); }); fr(); }; });
    sim(); fr();
    $('#share').onclick = function () {
      var data = { title: 'IMMOTION · ' + b.t, text: b.t + ' à ' + b.c + ', ' + eur(b.prix), url: location.href };
      if (navigator.share) navigator.share(data).catch(function () {}); else if (navigator.clipboard) navigator.clipboard.writeText(location.href).then(function () { toast('Lien <b>copié</b>'); });
    };
  };

  /* ----- Fiche location ----- */
  S.location = function (p) {
    var b = D.rent.filter(function (x) { return x.id === +p[0]; })[0]; if (!b) return notFound();
    renderTop({ back: true, title: b.t });
    var c = commune[b.c], vv = c && c.v, frais = b.loyer * 1.17 / 2;
    return '<div class="gal"><img src="' + img(b.img) + '" alt="' + esc(b.alt) + '">' + favBtn('l' + b.id) + '<div class="tags"><span class="tag">Disponible ' + b.dispo + '</span><span class="tag cr">Bien d’exemple</span></div></div>' +
      '<section class="sec stack" style="gap:6px"><span class="small muted">' + b.type + ' · ' + esc(b.c) + '</span><h1 class="disp" style="font-size:34px">' + esc(b.t) + '</h1><div class="row" style="align-items:baseline;gap:8px;margin-top:6px"><span class="big">' + eur(b.loyer) + '</span><span class="muted">/ mois</span></div><span class="small muted">' + (b.charges ? '+ ' + eur(b.charges) + ' de charges' : 'Charges selon consommation') + '</span></section>' +
      '<section class="sec" style="padding-top:0"><div class="facts"><div><span>Surface</span><b>' + b.m2 + ' m²</b></div><div><span>Chambres</span><b>' + (b.ch || 'Studio') + '</b></div><div><span>Classe énergie</span><b>' + (b.cl || '—') + '</b></div><div><span>Meublé</span><b>' + (b.meuble ? 'Oui' : 'Non') + '</b></div></div></section>' +
      '<section class="sec dark"><span class="eyebrow">Ce que vous payez à l’entrée</span><div style="margin-top:12px"><div class="kv"><span>Premier loyer' + (b.charges ? ' et charges' : '') + '</span><b>' + eur(b.loyer + (b.charges || 0)) + '</b></div><div class="kv"><span>Garantie locative (2 mois maximum)</span><b>' + eur(b.loyer * 2) + '</b></div><div class="kv"><span>Votre part des frais d’agence</span><b>' + eur(frais).replace(',00', '') + '</b></div></div>' +
      '<p class="tiny muted" style="margin:10px 0 0">Depuis le 1er août 2024, les frais d’agence (un mois de loyer + 17 % de TVA) sont partagés à parts égales entre bailleur et locataire, et la garantie ne peut dépasser deux mois de loyer hors charges.</p></section>' +
      (vv ? '<section class="sec"><div class="sec-h"><h2 class="disp" style="font-size:26px">Vivre à ' + esc(b.c) + '</h2><a class="more" href="#/commune/' + encodeURIComponent(b.c) + '">La commune</a></div><div class="grid2">' + [[vv.creche, 'crèches et maisons relais'], [vv.ecole, 'écoles fondamentales'], [vv.commerce + vv.resto, 'commerces, restos, cafés'], [vv.bus + vv.train + vv.tram, 'arrêts de bus, train, tram']].map(function (t) { return '<div class="tile"><b>' + fmt(t[0]) + '</b><span>' + t[1] + '</span></div>'; }).join('') + '</div></section>' : '') +
      '<section class="sec" style="padding-top:0"><a class="card adv" style="padding:14px" href="#/conseiller/matteo"><img src="' + img('aac41911') + '" alt=""><span class="grow"><span class="n">Matteo Rinaldi</span><br><span class="small muted">Location et gestion · FR · EN · IT</span></span>' + ic('arrow', 20) + '</a>' +
      '<a class="btn ghost block" style="margin-top:12px" href="' + desk('dossier-locataire.html') + '">' + ic('doc', 20) + 'Préparer mon dossier locataire</a></section>' +
      '<div style="height:70px"></div><div class="cta-bar"><a class="btn or" href="#/rdv?adv=matteo&loc=' + b.id + '">Visiter ce logement</a></div>';
  };

  /* ----- Estimation ----- */
  var est = store.get('est-draft', { step: 1, type: 'Appartement', projet: 'Vendre', c: '', m2: 90, ch: 2, etat: 'Bon état' });
  S.estimer = function () {
    renderTop({});
    var st = est.step;
    var head = '<section class="sec dark" style="padding-bottom:20px"><span class="eyebrow">Estimation gratuite</span><h1 class="disp" style="font-size:36px;margin:8px 0 14px">Combien vaut <em>votre bien ?</em></h1><div class="steps">' + [1, 2, 3, 4].map(function (i) { return '<i class="' + (i <= st ? 'on' : '') + '"></i>'; }).join('') + '</div><p class="tiny muted" style="margin:8px 0 0">' + ['', 'Étape 1 sur 3 · le bien', 'Étape 2 sur 3 · la commune', 'Étape 3 sur 3 · surface et état', 'Votre première fourchette'][st] + '</p></section>';
    var body = '';
    var opt = function (k, v, icn, sub) { return '<button class="opt" data-k="' + k + '" data-v="' + v + '" aria-pressed="' + (est[k] === v) + '"><span class="oi">' + ic(icn, 22) + '</span><span class="grow">' + v + (sub ? '<small>' + sub + '</small>' : '') + '</span></button>'; };
    if (st === 1) body = '<div class="stack"><b>Votre bien</b>' + opt('type', 'Appartement', 'building') + opt('type', 'Maison', 'house') + '<b style="margin-top:8px">Votre projet</b><div class="seg" id="pj">' + ['Vendre', 'Louer', 'Je me renseigne'].map(function (x) { return '<button data-v="' + x + '" aria-pressed="' + (est.projet === x) + '">' + x + '</button>'; }).join('') + '</div></div>';
    if (st === 2) body = '<div class="stack"><label class="field">Commune<input class="input" id="ec" list="dl-communes" value="' + esc(est.c) + '" placeholder="Tapez le nom de la commune" autocomplete="off"></label><div id="ec-hit"></div><b style="margin-top:6px">Communes fréquentes</b><div class="row" style="flex-wrap:wrap;gap:8px">' + ['Luxembourg', 'Strassen', 'Bertrange', 'Mamer', 'Hesperange', 'Esch-sur-Alzette'].map(function (n) { return '<button class="chip" data-cc="' + n + '" aria-pressed="' + (est.c === n) + '">' + n + '</button>'; }).join('') + '</div></div>';
    if (st === 3) body = '<div class="stack" style="gap:18px"><label class="field">Surface habitable<span class="row"><input type="range" id="em2" min="20" max="400" step="1" value="' + est.m2 + '"><b class="num" id="em2v" style="min-width:76px;text-align:right;color:var(--ink);font-size:20px">' + est.m2 + ' m²</b></span></label>' +
      '<div class="stack" style="gap:8px"><b>Chambres</b><div class="seg" id="ech">' + [1, 2, 3, 4, 5].map(function (x) { return '<button data-v="' + x + '" aria-pressed="' + (est.ch === x) + '">' + (x === 5 ? '5+' : x) + '</button>'; }).join('') + '</div></div>' +
      '<div class="stack" style="gap:8px"><b>État</b>' + [['Neuf', 'moins de 5 ans'], ['Bon état', 'habitable tel quel'], ['À rafraîchir', 'peintures, sols'], ['À rénover', 'gros travaux']].map(function (e) { return opt('etat', e[0], 'spark', e[1]); }).join('') + '</div></div>';
    if (st === 4) return head + estResult();
    var can = st !== 2 || commune[est.c];
    return head + '<section class="sec">' + body + '<div class="row" style="margin-top:22px">' + (st > 1 ? '<button class="btn ghost" id="eb">Retour</button>' : '') + '<button class="btn or grow" id="en"' + (can ? '' : ' disabled') + '>' + (st === 3 ? 'Voir mon estimation' : 'Continuer') + '</button></div></section>';
  };
  function estResult() {
    var c = commune[est.c], p = cPrice(c, est.type), e = cEst(c, est.type), r1k = function (x) { return Math.round(x / 1000) * 1000; }, mid = r1k(p * est.m2), lo = r1k(mid * 0.92), hi = r1k(mid * 1.08);
    var g = growth(/maison/i.test(est.type) ? c.sm : c.sa, 2015);
    var advs = D.advisors.filter(function (a) { return a.communes.indexOf(c.n) >= 0; }); var adv = advs[0] || D.advisors[0];
    return '<section class="sec"><div class="range-box"><span class="small" style="color:var(--cr-2)">' + est.type + ' · ' + est.m2 + ' m² · ' + esc(c.n) + '</span><div class="big" style="margin-top:8px;color:var(--orange)">' + meur(lo) + ' – ' + meur(hi) + '</div><div class="rng"><span class="m"></span></div><div class="row tiny" style="justify-content:space-between;color:var(--cr-2)"><span>Basse · ' + eur(lo) + '</span><b style="color:var(--cream)">' + eur(mid) + '</b><span>Haute · ' + eur(hi) + '</span></div>' +
      '<p class="tiny" style="color:var(--cr-2);margin:12px 0 0">Calculée à partir du prix ' + (e ? 'estimé' : 'moyen annoncé') + ' des ' + (/maison/i.test(est.type) ? 'maisons' : 'appartements') + ' à ' + esc(c.n) + ' (' + (e ? '≈ ' : '') + fmt(p) + ' €/m², Observatoire de l’Habitat). Indicative, sans visite : elle ne remplace pas un avis de valeur.</p></div>' +
      '<div class="grid2" style="margin-top:12px"><div class="tile" style="background:var(--sand)"><b>' + fmt(p) + '</b><span>€/m² en moyenne</span></div>' + (g != null ? '<div class="tile" style="background:var(--sand)"><b>' + (g > 0 ? '+' : '') + g + ' %</b><span>depuis 2015</span></div>' : '') + (c.pop ? '<div class="tile" style="background:var(--sand)"><b>' + fmt(c.pop) + '</b><span>habitants (2026)</span></div>' : '') + '<div class="tile" style="background:var(--sand)"><b>' + esc(est.etat) + '</b><span>état déclaré</span></div></div>' +
      '<h2 class="disp" style="font-size:24px;margin:24px 0 12px">Les prochaines étapes</h2><div class="stack"><a class="btn or block" href="#/rdv?adv=' + adv.id + '&objet=estimer">Visite gratuite pour une estimation précise</a><a class="btn block" href="#/commune/' + encodeURIComponent(c.n) + '">Voir les prix à ' + esc(c.n) + '</a>' + (est.projet === 'Louer' ? '<a class="btn ghost block" href="#/gestion">Je préfère mettre en location</a>' : '<a class="btn ghost block" href="#/offmarket">Vendre en toute discrétion (off-market)</a>') + '<button class="btn ghost block" id="er">Faire une nouvelle estimation</button></div>' +
      '<div class="card" style="padding:16px;margin-top:18px"><b>Ce qui fait monter le prix</b><p class="small muted" style="margin:4px 0 12px">Jardin orienté sud, garage, classe énergétique A ou B, rénovation récente, calme.</p><b>Ce qui le fait baisser</b><p class="small muted" style="margin:4px 0 0">Travaux à prévoir, classe énergétique F à I, nuisances, absence de stationnement.</p></div></section>';
  }
  S.estimer.after = function () {
    var save = function () { store.set('est-draft', est); };
    $$('.opt[data-k]').forEach(function (b) { b.onclick = function () { est[b.dataset.k] = b.dataset.v; save(); $$('.opt[data-k="' + b.dataset.k + '"]').forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); vibrate(); }; });
    $$('#pj button').forEach(function (b) { b.onclick = function () { est.projet = b.dataset.v; save(); $$('#pj button').forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); }; });
    $$('#ech button').forEach(function (b) { b.onclick = function () { est.ch = +b.dataset.v; save(); $$('#ech button').forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); }; });
    var m2 = $('#em2'); if (m2) m2.oninput = function () { est.m2 = +m2.value; $('#em2v').textContent = est.m2 + ' m²'; save(); };
    var ec = $('#ec');
    var setC = function (n) { est.c = n; save(); var en = $('#en'); if (en) en.disabled = !commune[n]; $$('[data-cc]').forEach(function (x) { x.setAttribute('aria-pressed', x.dataset.cc === n); }); var h = $('#ec-hit'); if (h) h.innerHTML = commune[n] ? '<div class="card row small" style="padding:12px">' + ic('check', 18, ' style="color:var(--forest)"') + '<span><b>' + esc(n) + '</b> · canton ' + esc(commune[n].ct) + '</span></div>' : ''; };
    if (ec) { ec.oninput = function () { var n = matchCommune(ec.value); setC(norm(ec.value) === norm(n) ? n : (n && ec.value.length > 2 ? n : '')); }; setC(est.c); }
    $$('[data-cc]').forEach(function (b) { b.onclick = function () { ec.value = b.dataset.cc; setC(b.dataset.cc); }; });
    var en = $('#en'); if (en) en.onclick = function () {
      est.step++; save();
      if (est.step === 4) { var l = store.get('ests', []); var c = commune[est.c], mid = cPrice(c, est.type) * est.m2; l.unshift({ type: est.type, c: est.c, m2: est.m2, mid: mid, d: Date.now() }); store.set('ests', l.slice(0, 10)); }
      rerender(true);
    };
    var eb = $('#eb'); if (eb) eb.onclick = function () { est.step--; save(); rerender(true); };
    var er = $('#er'); if (er) er.onclick = function () { est.step = 1; save(); rerender(true); };
  };

  /* ----- Communes ----- */
  S.communes = function (p, q) {
    renderTop({ back: true, title: 'Prix des communes' });
    var key = q.k === 'pm' ? 'pm' : 'pa', sel = q.c || '';
    var list = CM.slice().sort(function (a, b) { return b[key] - a[key]; }), mx = list[0][key];
    var vals = CM.map(function (c) { return c[key]; }), mn = Math.min.apply(null, vals);
    return '<section class="sec dark"><span class="eyebrow">Carte des 100 communes</span><h1 class="disp" style="font-size:34px;margin:8px 0 14px">Le prix au m², <em>commune par commune.</em></h1>' +
      '<div class="seg" style="margin-bottom:14px"><a class="btn" style="flex:1;min-height:40px;border-radius:11px;font-size:14px;' + (key === 'pa' ? 'background:var(--orange);color:var(--ink)' : 'background:transparent;color:var(--cr-2)') + '" href="#/communes?k=pa">Appartements</a><a class="btn" style="flex:1;min-height:40px;border-radius:11px;font-size:14px;' + (key === 'pm' ? 'background:var(--orange);color:var(--ink)' : 'background:transparent;color:var(--cr-2)') + '" href="#/communes?k=pm">Maisons</a></div>' +
      '<div class="map-wrap" id="cmap">' + mapSVG({ key: key, sel: sel }) + '</div>' +
      '<div class="legend" style="margin-top:10px"><span class="num">' + fmt(mn) + ' €</span><span class="grad" style="background:linear-gradient(90deg,rgb(44,74,60),#FF6A1F,#f2b98f)"></span><span class="num">' + fmt(mx) + ' €</span></div>' +
      '<p class="tiny muted" style="margin:8px 0 0">Touchez une commune. Prix annoncés au m² des 12 derniers mois, Observatoire de l’Habitat ; plus pâle : estimation IMMOTION faute d’annonces suffisantes.</p></section>' +
      '<section class="sec"><label class="field" style="margin-bottom:8px">Rechercher une commune<input class="input" id="cq" placeholder="Ex. Mamer, Wiltz, Esch…" autocomplete="off"></label><div id="clist">' +
      list.map(function (c) { var e = c[key === 'pa' ? 'pae' : 'pme']; return '<a class="crow" data-n="' + esc(norm(c.n)) + '" href="#/commune/' + encodeURIComponent(c.n) + '"><span style="width:124px" class="small"><b>' + esc(c.n) + '</b><br><span class="tiny muted">' + esc(c.ct) + '</span></span><span class="cb"><i style="width:' + (c[key] / mx * 100) + '%"></i></span><b class="num small' + (e ? ' est' : '') + '" style="width:78px;text-align:right">' + (e ? '≈ ' : '') + fmt(c[key]) + ' €</b></a>'; }).join('') + '</div></section>';
  };
  S.communes.after = function (p, q) {
    var key = q.k === 'pm' ? 'pm' : 'pa';
    $('#cmap').addEventListener('click', function (e) {
      var path = e.target.closest('path[data-c]'); if (!path) return;
      var c = commune[path.dataset.c]; vibrate();
      $$('#cmap path.sel').forEach(function (x) { x.classList.remove('sel'); }); path.classList.add('sel');
      var e2 = c[key === 'pa' ? 'pae' : 'pme'];
      sheet('<span class="eyebrow">Canton ' + esc(c.ct) + '</span><h3 class="disp" style="font-size:30px;margin:6px 0 14px">' + esc(c.n) + '</h3><div class="grid2"><div class="tile"><b>' + (c.pae ? '≈ ' : '') + fmt(c.pa) + '</b><span>€/m² appartements</span></div><div class="tile"><b>' + (c.pme ? '≈ ' : '') + fmt(c.pm) + '</b><span>€/m² maisons</span></div></div><div class="row" style="margin-top:16px"><a class="btn ghost grow" style="color:var(--cream)" href="#/commune/' + encodeURIComponent(c.n) + '">Tout sur la commune</a><a class="btn or grow" href="#/estimer" data-estc="' + esc(c.n) + '">Estimer ici</a></div>', true);
      var bt = $('[data-estc]'); if (bt) bt.onclick = function () { est = { step: 3, type: key === 'pm' ? 'Maison' : 'Appartement', projet: 'Vendre', c: c.n, m2: key === 'pm' ? 140 : 90, ch: key === 'pm' ? 3 : 2, etat: 'Bon état' }; store.set('est-draft', est); };
      void e2;
    });
    var cq = $('#cq'); cq.oninput = function () { var v = norm(cq.value); $$('#clist .crow').forEach(function (r) { r.hidden = v && r.dataset.n.indexOf(v) < 0; }); };
  };
  S.commune = function (p) {
    var c = commune[decodeURIComponent(p[0] || '')]; if (!c) return notFound();
    renderTop({ back: true, title: c.n });
    var v = c.v, ga = growth(c.sa, 2015), gm = growth(c.sm, 2015);
    var biens = D.sale.filter(function (b) { return b.c === c.n; }), locs = D.rent.filter(function (b) { return b.c === c.n; });
    var advs = D.advisors.filter(function (a) { return a.communes.indexOf(c.n) >= 0; });
    var vivre = [[v.creche, 'Crèches et maisons relais'], [v.ecole, 'Écoles fondamentales'], [v.lycee, 'Lycées'], [v.intl, 'Écoles internationales'], [v.pharma, 'Pharmacies'], [v.medical, 'Médecins et soins'], [v.commerce, 'Commerces'], [v.resto, 'Restaurants et cafés'], [v.sport + v.fitness, 'Lieux de sport'], [v.bus, 'Arrêts de bus'], [v.train, 'Gares CFL'], [v.tram, 'Arrêts de tram']];
    return '<section class="sec dark"><span class="eyebrow">Immobilier à ' + esc(c.n) + ' · canton ' + esc(c.ct) + '</span><h1 class="disp" style="font-size:40px;margin:8px 0 16px">Vivre et investir <em>à ' + esc(c.n) + '</em></h1>' +
      '<div class="grid2"><div class="tile"><b style="color:var(--orange)">' + (c.pae ? '≈ ' : '') + fmt(c.pa) + '</b><span>€/m² appartements' + (ga != null ? ' · ' + (ga > 0 ? '+' : '') + ga + ' % depuis 2015' : '') + '</span></div><div class="tile"><b>' + (c.pme ? '≈ ' : '') + fmt(c.pm) + '</b><span>€/m² maisons' + (gm != null ? ' · ' + (gm > 0 ? '+' : '') + gm + ' % depuis 2015' : '') + '</span></div>' +
      (c.pop ? '<div class="tile"><b>' + fmt(c.pop) + '</b><span>habitants (2026)</span></div>' : '') + (c.et != null ? '<div class="tile"><b>' + String(c.et).replace('.', ',') + ' %</b><span>résidents étrangers</span></div>' : '') + '</div>' +
      '<h2 class="disp" style="font-size:22px;margin:22px 0 10px">Les prix depuis 2010</h2>' + lineChart(c) +
      '<p class="tiny muted" style="margin:10px 0 0">Prix annoncés, Observatoire de l’Habitat.' + ((c.pae || c.pme) ? ' « ≈ » : estimation IMMOTION, faute d’annonces suffisantes.' : '') + '</p></section>' +
      '<section class="sec"><h2 class="disp" style="font-size:26px;margin-bottom:12px">Vivre à ' + esc(c.n) + '</h2><div class="card" style="padding:4px 16px">' + vivre.map(function (x) { return '<div class="kv"><span>' + x[1] + '</span><b>' + fmt(x[0] || 0) + '</b></div>'; }).join('') + '</div><p class="tiny muted">Équipements dans les limites de la commune, OpenStreetMap (28 septembre 2026). Ordres de grandeur.</p></section>' +
      ((biens.length || locs.length) ? '<section class="sec" style="padding-top:0"><h2 class="disp" style="font-size:26px;margin-bottom:12px">Nos biens à ' + esc(c.n) + '</h2><div class="list">' + biens.map(saleCard).join('') + locs.map(rentCard).join('') + '</div></section>' : '') +
      (advs.length ? '<section class="sec" style="padding-top:0"><span class="eyebrow">Votre conseiller local</span>' + advs.map(function (a) { return '<a class="card adv" style="padding:14px;margin-top:10px" href="#/conseiller/' + a.id + '"><img src="' + img(a.av) + '" alt=""><span class="grow"><span class="n">' + a.n + '</span><br><span class="small muted">' + a.short + '</span></span>' + ic('arrow', 20) + '</a>'; }).join('') + '</section>' : '') +
      '<section class="sec" style="padding-top:0"><div class="stack"><a class="btn or block" href="#/estimer" id="est-here">Estimer mon bien à ' + esc(c.n) + '</a><a class="btn ghost block" href="#/communes?c=' + encodeURIComponent(c.n) + '">' + ic('map', 20) + 'Voir sur la carte</a></div></section>' + footer();
  };
  S.commune.after = function (p) {
    var c = commune[decodeURIComponent(p[0] || '')]; var b = $('#est-here');
    if (b && c) b.onclick = function () { est = { step: 1, type: est.type || 'Appartement', projet: 'Vendre', c: c.n, m2: est.m2 || 90, ch: est.ch || 2, etat: 'Bon état' }; store.set('est-draft', est); };
  };

  /* ----- Rendez-vous ----- */
  function freshRdv() { var me = store.get('me', null) || {}; return { step: 1, projet: 'Acheter', lang: 'FR', adv: null, mode: 'En agence', day: null, slot: null, nom: me.nom || '', mail: me.mail || '', tel: '' }; }
  var rdv = freshRdv();
  function slotsFor(advId, day) {
    var T = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00', '18:00'];
    return T.map(function (t, i) { var h = 0, s = advId + day + t; for (var k = 0; k < s.length; k++) h = (h * 31 + s.charCodeAt(k)) % 997; return { t: t, ok: h % 5 > 1 }; });
  }
  function days() {
    var out = [], d = new Date(); d.setHours(0, 0, 0, 0);
    while (out.length < 12) { d.setDate(d.getDate() + 1); if (d.getDay() !== 0) out.push(new Date(d)); }
    return out;
  }
  var JOURS = ['Dim.', 'Lun.', 'Mar.', 'Mer.', 'Jeu.', 'Ven.', 'Sam.'], MOIS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
  S.rdv = function (p, q) {
    renderTop({ back: true, title: 'Prendre rendez-vous', noRdv: true });
    var key = location.hash;
    if (rdv._key !== key || rdv._done) {
      rdv = freshRdv(); rdv._key = key;
      if (q.adv) { rdv.adv = q.adv; rdv.step = 3; }
      rdv.projet = q.objet === 'estimer' ? 'Vendre ou estimer' : q.loc ? 'Louer' : q.adv === 'matteo' ? 'Mettre en location' : 'Acheter';
    }
    var bien = q.bien ? D.sale.filter(function (b) { return b.id === +q.bien; })[0] : q.loc ? D.rent.filter(function (b) { return b.id === +q.loc; })[0] : null;
    if (bien) rdv.bien = bien.t + ' · ' + bien.c;
    var st = rdv.step;
    var head = '<section class="sec dark" style="padding-bottom:18px"><span class="eyebrow">' + (bien ? 'Visite · ' + esc(bien.t) : 'Rendez-vous') + '</span><h1 class="disp" style="font-size:32px;margin:8px 0 14px">' + ['', 'Votre projet', 'Avec qui ?', 'Quand ?', 'Vos coordonnées', 'C’est réservé.'][st] + '</h1>' + (st < 5 ? '<div class="steps">' + [1, 2, 3, 4].map(function (i) { return '<i class="' + (i <= st ? 'on' : '') + '"></i>'; }).join('') + '</div>' : '') + '</section>';
    var a = D.advisors.filter(function (x) { return x.id === rdv.adv; })[0];
    if (st === 1) return head + '<section class="sec stack" style="gap:18px"><div class="stack" style="gap:8px"><b>Votre projet</b><div class="row" style="flex-wrap:wrap;gap:8px">' + ['Acheter', 'Vendre ou estimer', 'Louer', 'Mettre en location', 'Autre question'].map(function (x) { return '<button class="chip" data-pj="' + x + '" aria-pressed="' + (rdv.projet === x) + '">' + x + '</button>'; }).join('') + '</div></div>' +
      '<div class="stack" style="gap:8px"><b>Je préfère parler en</b><div class="row" style="flex-wrap:wrap;gap:8px">' + [['FR', 'Français'], ['DE', 'Deutsch'], ['EN', 'English'], ['LU', 'Lëtzebuergesch'], ['PT', 'Português'], ['IT', 'Italiano']].map(function (x) { return '<button class="chip" data-lg="' + x[0] + '" aria-pressed="' + (rdv.lang === x[0]) + '">' + x[1] + '</button>'; }).join('') + '</div></div><button class="btn or block" data-next>Continuer</button></section>';
    if (st === 2) {
      var advs = D.advisors.slice().sort(function (x, y) { return (y.langs.indexOf(rdv.lang) >= 0) - (x.langs.indexOf(rdv.lang) >= 0); });
      return head + '<section class="sec stack"><button class="advpick" data-adv="first" aria-pressed="' + (rdv.adv === 'first') + '" style="background:var(--orange);border-color:var(--orange)"><span style="width:56px;height:56px;border-radius:50%;background:var(--ink);display:grid;place-items:center;color:var(--orange);flex:none">' + ic('spark', 26) + '</span><span class="grow"><b>Le premier conseiller disponible</b><br><span class="small">Le plus rapide : celui qui parle votre langue et connaît votre projet.</span></span></button>' +
        advs.map(function (x) { return '<button class="advpick" data-adv="' + x.id + '" aria-pressed="' + (rdv.adv === x.id) + '"><img src="' + img(x.av) + '" alt=""><span class="grow"><b>' + x.n + '</b><br><span class="small muted">' + x.short + ' · ' + esc(x.zone) + '</span><span class="langs">' + x.langs.map(function (l) { return '<span' + (l === rdv.lang ? ' style="background:var(--orange);color:var(--ink)"' : '') + '>' + l + '</span>'; }).join('') + '</span></span></button>'; }).join('') +
        '<div class="row"><button class="btn ghost" data-prev>Retour</button><button class="btn or grow" data-next' + (rdv.adv ? '' : ' disabled') + '>Voir les créneaux</button></div></section>';
    }
    if (st === 3) {
      var ds = days(); if (!rdv.day) rdv.day = ds[0].toISOString().slice(0, 10);
      var sl = slotsFor(rdv.adv || 'first', rdv.day);
      return head + '<section class="sec stack" style="gap:16px">' + (a ? '<div class="adv"><img src="' + img(a.av) + '" alt=""><span><span class="n">' + a.n + '</span><br><span class="small muted">' + a.short + '</span></span></div>' : '<div class="small muted">Premier conseiller disponible</div>') +
        '<div class="seg" id="mode">' + ['En agence', 'En visio', 'Sur place'].map(function (x) { return '<button data-v="' + x + '" aria-pressed="' + (rdv.mode === x) + '">' + x + '</button>'; }).join('') + '</div>' +
        '<div class="days">' + ds.map(function (d) { var iso = d.toISOString().slice(0, 10); return '<button class="day" data-day="' + iso + '" aria-pressed="' + (rdv.day === iso) + '">' + JOURS[d.getDay()] + '<b>' + d.getDate() + '</b>' + MOIS[d.getMonth()] + '</button>'; }).join('') + '</div>' +
        '<div class="slots">' + sl.map(function (s) { return '<button class="slot" data-slot="' + s.t + '"' + (s.ok ? '' : ' disabled') + ' aria-pressed="' + (rdv.slot === s.t) + '">' + s.t + '</button>'; }).join('') + '</div><p class="tiny muted" style="margin:0">Créneaux d’exemple. Dans la version finale, ils viendront en direct de l’agenda du conseiller.</p>' +
        '<div class="row"><button class="btn ghost" data-prev>Retour</button><button class="btn or grow" data-next' + (rdv.slot ? '' : ' disabled') + '>Continuer</button></div></section>';
    }
    if (st === 4) {
      var d = new Date(rdv.day + 'T00:00:00');
      return head + '<section class="sec stack"><div class="card row" style="padding:14px"><span class="tag">' + ic('cal', 14) + '</span><span class="grow"><b>' + JOURS[d.getDay()] + ' ' + d.getDate() + ' ' + MOIS[d.getMonth()] + ' à ' + rdv.slot + '</b><br><span class="small muted">' + rdv.mode + ' · ' + (a ? a.n : 'premier conseiller disponible') + '</span></span></div>' +
        '<label class="field">Nom<input class="input" id="r-n" autocomplete="name" value="' + esc(rdv.nom) + '" placeholder="Prénom et nom"></label><label class="field">E-mail<input class="input" id="r-m" type="email" autocomplete="email" value="' + esc(rdv.mail) + '" placeholder="vous@exemple.lu"></label><label class="field">Téléphone (facultatif)<input class="input" id="r-t" type="tel" autocomplete="tel" value="' + esc(rdv.tel) + '" placeholder="+352 …"></label>' +
        '<p class="tiny muted" style="margin:0">Vos coordonnées servent uniquement à organiser ce rendez-vous. <a href="' + desk('legal.html#confidentialite') + '" style="text-decoration:underline">Confidentialité</a></p><div class="row"><button class="btn ghost" data-prev>Retour</button><button class="btn or grow" id="r-ok">Confirmer le rendez-vous</button></div></section>';
    }
    var last = store.get('rdvs', [])[0] || {};
    return head + '<section class="sec" style="text-align:center"><div class="okmark">' + ic('check', 40) + '</div><p style="font-size:18px;margin:0 0 6px"><b>' + esc(last.label || '') + '</b></p><p class="muted" style="margin:0 0 20px">' + esc(last.who || '') + ' · ' + esc(last.mode || '') + '<br>Une confirmation part à votre adresse e-mail.</p>' +
      '<div class="stack"><a class="btn block" target="_blank" rel="noopener" href="' + (last.cal || '#') + '">' + ic('cal', 20) + 'Ajouter à mon agenda</a><a class="btn ghost block" href="#/moi">Voir dans mon espace</a><a class="btn ghost block" href="#/" id="r-home">Retour à l’accueil</a></div><p class="tiny muted" style="margin-top:16px">Démonstration : aucun e-mail n’est encore envoyé.</p></section>';
  };
  S.rdv.after = function () {
    $$('[data-pj]').forEach(function (b) { b.onclick = function () { rdv.projet = b.dataset.pj; $$('[data-pj]').forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); }; });
    $$('[data-lg]').forEach(function (b) { b.onclick = function () { rdv.lang = b.dataset.lg; $$('[data-lg]').forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); }; });
    $$('[data-adv]').forEach(function (b) { b.onclick = function () { rdv.adv = b.dataset.adv; rdv.slot = null; rerender(); }; });
    $$('#mode button').forEach(function (b) { b.onclick = function () { rdv.mode = b.dataset.v; $$('#mode button').forEach(function (x) { x.setAttribute('aria-pressed', x === b); }); }; });
    $$('[data-day]').forEach(function (b) { b.onclick = function () { rdv.day = b.dataset.day; rdv.slot = null; rerender(); }; });
    $$('[data-slot]').forEach(function (b) { b.onclick = function () { rdv.slot = b.dataset.slot; vibrate(); rerender(); }; });
    $$('[data-next]').forEach(function (b) { b.onclick = function () { rdv.step++; rerender(true); }; });
    $$('[data-prev]').forEach(function (b) { b.onclick = function () { rdv.step--; rerender(true); }; });
    var ok = $('#r-ok'); if (ok) ok.onclick = function () {
      rdv.nom = $('#r-n').value.trim(); rdv.mail = $('#r-m').value.trim(); rdv.tel = $('#r-t').value.trim();
      if (!rdv.nom || !/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(rdv.mail)) { toast('Indiquez votre nom et une adresse e-mail valide'); ($('#r-n').value ? $('#r-m') : $('#r-n')).focus(); return; }
      var a = D.advisors.filter(function (x) { return x.id === rdv.adv; })[0];
      var d = new Date(rdv.day + 'T' + rdv.slot + ':00'), end = new Date(d.getTime() + 45 * 60000);
      var g = function (x) { return x.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, ''); };
      var label = JOURS[d.getDay()] + ' ' + d.getDate() + ' ' + MOIS[d.getMonth()] + ' à ' + rdv.slot;
      var cal = 'https://calendar.google.com/calendar/render?action=TEMPLATE&text=' + encodeURIComponent('Rendez-vous IMMOTION' + (rdv.bien ? ' · ' + rdv.bien : '')) + '&dates=' + g(d) + '/' + g(end) + '&details=' + encodeURIComponent(rdv.projet + ' · ' + rdv.mode);
      var l = store.get('rdvs', []); l.unshift({ label: label, ts: d.getTime(), who: a ? a.n : 'Premier conseiller disponible', mode: rdv.mode, projet: rdv.projet, bien: rdv.bien || '', cal: cal }); store.set('rdvs', l);
      store.set('me', { nom: rdv.nom, mail: rdv.mail });
      rdv.step = 5; vibrate(); rerender(true);
    };
    var h = $('#r-home'); if (h) h.onclick = function () { rdv = freshRdv(); };
    if (rdv.step === 5) rdv._done = true;
  };

  /* ----- Assistant ----- */
  var chat = { msgs: [] };
  try { var sv = JSON.parse(sessionStorage.getItem((window.IMMOTION_BRAIN || {}).store || 'immotion-assistant-v1') || 'null'); if (sv && sv.msgs) chat.msgs = sv.msgs; } catch (e) {}
  function chatSave() { try { sessionStorage.setItem((window.IMMOTION_BRAIN || {}).store || 'immotion-assistant-v1', JSON.stringify({ open: false, msgs: chat.msgs.slice(-40) })); } catch (e) {} }
  function appHref(h) {
    var m;
    if ((m = /^bien\.html#b(\d)/.exec(h))) return '#/bien/' + m[1];
    if ((m = /^location\.html#l(\d)/.exec(h))) return '#/location/' + m[1];
    var map = { 'acheter.html': '#/biens', 'recherche.html': '#/biens', 'louer.html': '#/biens?m=louer', 'recherche-location.html': '#/biens?m=louer', 'bien.html': '#/bien/1', 'location.html': '#/location/2', 'estimer-bien.html': '#/estimer', 'estimer.html': '#/estimer', 'rdv-choix.html': '#/rdv', 'carte.html': '#/communes', 'offmarket.html': '#/offmarket', 'honoraires.html': '#/honoraires', 'gestion.html': '#/gestion', 'agence.html': '#/agence', 'faq.html': '#/faq', 'newsletter.html': '#/newsletter', 'client-connexion.html': '#/moi', 'assistant.html': '#/assistant', 'index.html': '#/' };
    var base = h.split('#')[0];
    if (map[base]) return map[base];
    if (/^https?:/.test(h)) return h;
    return desk(h);
  }
  function itemImg(href) { var m = /#b(\d)/.exec(href), n = /#l(\d)/.exec(href); var b = m ? D.sale[+m[1] - 1] : n ? D.rent[+n[1] - 1] : null; return b ? '<img src="' + img(b.img) + '" alt="">' : ''; }
  function msgHTML(m) {
    if (m.typing) return '<div class="msg bot"><span class="typing" aria-label="L’assistant écrit"><i></i><i></i><i></i></span></div>';
    var h = '<div class="msg ' + (m.role === 'user' ? 'me' : 'bot') + '">' + esc(m.text) + (m.extra ? '<span class="x">' + esc(m.extra) + '</span>' : '') +
      (m.items && m.items.length ? '<span class="it">' + m.items.map(function (i) { return '<a href="' + appHref(i.href) + '">' + itemImg(i.href) + '<span><b>' + esc(i.title) + '</b><span>' + esc(i.sub) + '</span></span></a>'; }).join('') + '</span>' : '') + '</div>';
    if (m.actions && m.actions.length) h += '<div class="acts">' + m.actions.map(function (a) { return '<a href="' + appHref(a.href) + '">' + esc(a.label) + '</a>'; }).join('') + '</div>';
    return h;
  }
  S.assistant = function () {
    renderTop({});
    var B = window.IMMOTION_BRAIN;
    var hello = { role: 'assistant', text: B ? B.hello : 'Moien !', actions: [{ label: 'Trouver un bien', href: 'acheter.html' }, { label: 'Estimer', href: 'estimer-bien.html' }, { label: 'Rendez-vous', href: 'rdv-choix.html' }] };
    var msgs = chat.msgs.length ? chat.msgs : [hello];
    return '<div class="chat"><div class="row" style="background:var(--forest);padding:12px 16px;gap:12px"><span style="width:42px;height:42px;border-radius:50%;background:var(--ink);display:grid;place-items:center;flex:none"><span class="wm" style="font-size:9px;color:transparent"><span class="pill" style="width:3.2em;height:1.2em;margin:0"></span></span></span><span class="grow"><b>Assistant IMMOTION</b><br><span class="small" style="color:var(--cr-2)">En ligne · FR · DE · EN</span></span><button class="icon-btn" id="ch-new" aria-label="Nouvelle conversation" style="color:var(--cream)">↺</button></div>' +
      '<div class="chat-log" id="log" aria-live="polite">' + msgs.map(msgHTML).join('') + '</div>' +
      (chat.msgs.length < 3 ? '<div class="sugs">' + ['Un 3 chambres à Strassen ?', 'Prix au m² à Bertrange', 'Estimer une maison de 140 m² à Mamer', 'Louer à Luxembourg', 'Vos honoraires ?', 'Frais de notaire ?'].map(function (s) { return '<button class="chip" data-sug="' + esc(s) + '">' + esc(s) + '</button>'; }).join('') + '</div>' : '') +
      '<form class="composer" id="cf"><label for="ci" class="sr">Votre message</label><input id="ci" autocomplete="off" placeholder="Écrire à l’assistant" maxlength="500" enterkeyhint="send"><button type="submit" aria-label="Envoyer">' + ic('send', 20, ' style="color:var(--ink)"') + '</button></form>' +
      '<p class="tiny" style="text-align:center;color:var(--cr-3);margin:0;padding:0 16px 12px;background:var(--ink)">' + ((window.IMMOTION_AGENT || {}).endpoint ? 'Réponses de votre agent IA' : 'Réponses indicatives · un conseiller confirme toujours') + '</p></div>';
  };
  S.assistant.after = function () {
    var log = $('#log'), busy = false;
    var scroll = function () { window.scrollTo(0, document.body.scrollHeight); };
    scroll();
    function ask(text) {
      text = String(text || '').trim(); if (!text || busy || !window.IMMOTION_BRAIN) return;
      busy = true; var hist = chat.msgs.map(function (m) { return { role: m.role, text: m.text }; });
      chat.msgs.push({ role: 'user', text: text }); chatSave();
      log.insertAdjacentHTML('beforeend', msgHTML({ role: 'user', text: text }) + msgHTML({ typing: true })); scroll();
      var s = $('.sugs'); if (s && chat.msgs.length > 2) s.remove();
      var t0 = Date.now();
      window.IMMOTION_BRAIN.ask(text, hist).then(function (a) {
        setTimeout(function () {
          var m = { role: 'assistant', text: a.reply, extra: a.extra, items: a.items, actions: a.actions };
          chat.msgs.push(m); chatSave();
          var ty = $('.typing', log); if (ty) ty.parentNode.remove();
          log.insertAdjacentHTML('beforeend', msgHTML(m)); busy = false; scroll(); vibrate();
        }, Math.max(0, 500 - (Date.now() - t0)));
      });
    }
    $('#cf').onsubmit = function (e) { e.preventDefault(); var i = $('#ci'); ask(i.value); i.value = ''; };
    $$('[data-sug]').forEach(function (b) { b.onclick = function () { ask(b.dataset.sug); }; });
    $('#ch-new').onclick = function () { chat.msgs = []; chatSave(); rerender(); };
  };

  /* ----- Mon espace ----- */
  S.moi = function (p) {
    renderTop({});
    var me = store.get('me', null);
    if (!me && p[0] !== 'favoris') {
      return '<section class="sec dark" style="min-height:60vh"><span class="eyebrow">Mon espace</span><h1 class="disp" style="font-size:38px;margin:8px 0 12px">Votre projet, <em>suivi pas à pas.</em></h1><p class="muted">Favoris, alertes, visites, estimations et documents, au même endroit. Pas de mot de passe : nous vous envoyons un lien de connexion.</p>' +
        '<form id="lg" class="stack" style="margin-top:18px"><label class="field" style="color:var(--cr-2)">Adresse e-mail<input class="input" id="lg-m" type="email" autocomplete="email" placeholder="vous@exemple.lu" required></label><button class="btn or block">Recevoir mon lien de connexion</button></form>' +
        '<p class="tiny muted" style="margin-top:12px">Démonstration : la connexion se fait directement, sans e-mail.</p></section>' + moiContent(null);
    }
    return moiContent(me);
  };
  function moiContent(me) {
    var f = favs(), rd = store.get('rdvs', []), es = store.get('ests', []), al = store.get('alerts', []);
    var fl = f.map(function (k) { var b = k[0] === 'b' ? D.sale[+k.slice(1) - 1] : D.rent[+k.slice(1) - 1]; return b ? (k[0] === 'b' ? saleCard(b) : rentCard(b)) : ''; }).join('');
    return (me ? '<section class="sec dark"><div class="row"><span class="grow"><span class="eyebrow">Mon espace</span><h1 class="disp" style="font-size:34px;margin-top:6px">Bonjour ' + esc((me.nom || '').split(' ')[0] || '') + '</h1><span class="small muted">' + esc(me.mail) + '</span></span><button class="chip" id="lo">Se déconnecter</button></div></section>' : '') +
      '<section class="sec"><div class="sec-h"><h2 class="disp" style="font-size:24px">Mes rendez-vous</h2><a class="more" href="#/rdv">Nouveau</a></div>' + (rd.length ? '<div class="stack">' + rd.slice(0, 4).map(function (r) { return '<div class="card row" style="padding:14px"><span class="tag" style="background:' + (r.ts > Date.now() ? 'var(--orange)' : 'var(--stone)') + '">' + ic('cal', 14) + '</span><span class="grow"><b>' + esc(r.label) + '</b><br><span class="small muted">' + esc(r.who) + ' · ' + esc(r.mode) + (r.bien ? ' · ' + esc(r.bien) : '') + '</span></span><a href="' + r.cal + '" target="_blank" rel="noopener" aria-label="Ajouter à l’agenda">' + ic('arrow', 20) + '</a></div>'; }).join('') + '</div>' : '<p class="small muted">Aucun rendez-vous pour l’instant.</p>') + '</section>' +
      '<section class="sec" style="padding-top:0"><div class="sec-h"><h2 class="disp" style="font-size:24px">Mes favoris</h2><span class="small muted">' + f.length + '</span></div>' + (f.length ? '<div class="rail">' + fl + '</div>' : '<div class="empty" style="padding:20px"><div class="ei">' + ic('heart', 26) + '</div><p class="small">Touchez le cœur d’un bien pour le retrouver ici.</p><a class="btn" href="#/biens">Voir les biens</a></div>') + '</section>' +
      '<section class="sec" style="padding-top:0"><div class="sec-h"><h2 class="disp" style="font-size:24px">Mes estimations</h2><a class="more" href="#/estimer">Nouvelle</a></div>' + (es.length ? '<div class="stack">' + es.slice(0, 3).map(function (e) { return '<div class="card row" style="padding:14px"><span class="grow"><b>' + e.type + ' · ' + e.m2 + ' m² · ' + esc(e.c) + '</b><br><span class="small muted">environ ' + eur(e.mid) + '</span></span></div>'; }).join('') + '</div>' : '<p class="small muted">Aucune estimation enregistrée.</p>') + '</section>' +
      '<section class="sec" style="padding-top:0"><div class="sec-h"><h2 class="disp" style="font-size:24px">Mes alertes</h2></div>' + (al.length ? '<div class="stack">' + al.slice(0, 5).map(function (a, i) { var x = a.f || {}; return '<div class="card row" style="padding:14px">' + ic('bell', 20) + '<span class="grow small"><b>' + (a.m === 'louer' ? 'Location' : 'Achat') + '</b> · ' + esc([x.c, x.t, x.b ? '≤ ' + eur(x.b) : '', x.ch ? x.ch + ' ch. et +' : ''].filter(Boolean).join(' · ') || 'tous les biens') + '</span><button class="chip" data-del-al="' + i + '" style="min-height:34px;padding:4px 10px">Supprimer</button></div>'; }).join('') + '</div>' : '<p class="small muted">Créez une alerte depuis la liste des biens.</p>') + '</section>' +
      '<section class="sec" style="padding-top:0"><div class="stack"><a class="card row" style="padding:16px" href="#/assistant">' + ic('chat', 22) + '<span class="grow"><b>Messages et questions</b><br><span class="small muted">L’assistant répond tout de suite, un conseiller prend le relais.</span></span>' + ic('arrow', 20) + '</a>' +
      '<a class="card row" style="padding:16px" href="' + desk('client-documents.html') + '">' + ic('doc', 22) + '<span class="grow"><b>Mes documents</b><br><span class="small muted">Dans l’espace client complet (version ordinateur).</span></span>' + ic('arrow', 20) + '</a>' + installCard() + '</div></section>' + footer();
  }
  S.moi.after = function () {
    var lg = $('#lg'); if (lg) lg.onsubmit = function (e) { e.preventDefault(); var m = $('#lg-m').value.trim(); if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(m)) { toast('Adresse e-mail invalide'); return; } store.set('me', { nom: '', mail: m }); toast('Vous êtes <b>connecté</b>'); rerender(); };
    var lo = $('#lo'); if (lo) lo.onclick = function () { store.set('me', null); rerender(); };
    $$('[data-del-al]').forEach(function (b) { b.onclick = function () { var a = store.get('alerts', []); a.splice(+b.dataset.delAl, 1); store.set('alerts', a); rerender(); }; });
  };

  /* ----- Off-market ----- */
  S.offmarket = function () {
    renderTop({ back: true, title: 'Off-market' });
    var ok = store.get('om', false);
    return '<section class="dark" style="position:relative"><img src="' + img('fff76aeb') + '" alt="Un explorateur aux jumelles" style="width:100%;aspect-ratio:3/2;object-fit:cover;object-position:60% 30%"><div class="sec" style="padding-top:8px"><span class="eyebrow">Off-market · accès réservé</span><h1 class="disp" style="font-size:38px;margin:8px 0 10px">Des biens qu’on ne voit <em>nulle part ailleurs.</em></h1><p class="muted" style="margin:0">Soyez le premier à découvrir votre prochain chez-vous : des biens vendus sans annonce publique, présentés d’abord aux acheteurs dont le financement est vérifié.</p></div></section>' +
      '<section class="sec"><div class="stack" style="gap:6px;margin-bottom:18px">' + [['1', 'Créez votre espace', 'Vos critères et votre budget.'], ['2', 'Validez votre projet', 'Un accord de principe de votre banque.'], ['3', 'Voyez avant tout le monde', 'Photos, adresse et prix, sur rendez-vous.']].map(function (s) { return '<div class="row" style="padding:10px 0;border-bottom:1px solid var(--line)"><span class="tag ink" style="min-width:26px;text-align:center">' + s[0] + '</span><span><b>' + s[1] + '</b><br><span class="small muted">' + s[2] + '</span></span></div>'; }).join('') + '</div>' +
      '<div class="sec-h"><h2 class="disp" style="font-size:24px">' + (ok ? 'Biens disponibles' : 'Aperçu') + '</h2><span class="demo">Données d’exemple</span></div><div class="list">' +
      D.offmarket.map(function (o) { return '<div class="pcard"><div class="ph" style="aspect-ratio:16/10">' + (o.img ? '<img src="' + img(o.img) + '" alt="" loading="lazy" style="' + (ok ? '' : 'filter:blur(14px) saturate(.7);transform:scale(1.1)') + '">' : '<div style="width:100%;height:100%;background:radial-gradient(circle at 70% 60%,rgba(255,106,31,.55),transparent 60%),var(--forest)"></div>') + '<div class="tags"><span class="tag">' + o.tag + '</span></div>' + (ok ? '' : '<span style="position:absolute;inset:0;display:grid;place-items:center;color:var(--cream)">' + ic('lock', 34) + '</span>') + '</div><div class="body"><span class="loc">' + o.type + ' · ' + esc(o.zone) + '</span><span class="t">' + esc(o.t) + '</span><span class="meta">' + (ok ? 'Prix et adresse communiqués en rendez-vous' : 'Réservé aux acheteurs vérifiés') + '</span></div></div>'; }).join('') + '</div>' +
      (ok ? '<a class="btn or block" style="margin-top:18px" href="#/rdv?adv=tiago">Demander une visite accompagnée</a>' :
        '<form id="om" class="card stack" style="padding:16px;margin-top:18px"><b style="font-size:18px">Demander l’accès</b><label class="field">E-mail<input class="input" id="om-m" type="email" placeholder="vous@exemple.lu" required></label><label class="field">Financement<select class="input" id="om-f"><option>Accord de principe obtenu</option><option>En cours auprès de ma banque</option><option>Achat comptant</option></select></label><label class="row small"><input type="checkbox" id="om-c" required style="width:20px;height:20px;accent-color:var(--orange)"> Je m’engage à garder les informations confidentielles.</label><button class="btn or block">Demander l’accès off-market</button><p class="tiny muted" style="margin:0">Démonstration : l’accès s’ouvre directement.</p></form>') + '</section>' + footer();
  };
  S.offmarket.after = function () { var f = $('#om'); if (f) f.onsubmit = function (e) { e.preventDefault(); if (!$('#om-c').checked) return; store.set('om', true); toast('Accès off-market <b>ouvert</b>'); rerender(); }; };

  /* ----- Gestion ----- */
  S.gestion = function () {
    renderTop({ back: true, title: 'Gestion locative' });
    return '<section class="sec dark"><span class="eyebrow">Gestion immobilière</span><h1 class="disp" style="font-size:38px;margin:8px 0 10px">Vous avez un bien ? <em>On s’en occupe.</em></h1><p class="muted">Du choix du locataire au décompte annuel des charges, nous gérons votre logement comme si c’était le nôtre.</p>' +
      '<div class="grid2" style="margin-top:16px"><div class="tile"><b style="color:var(--orange)">1</b><span>seul interlocuteur pour le locataire, les artisans et le syndic</span></div><div class="tile"><b style="color:var(--orange)">24/7</b><span>ligne d’urgence : dégâts des eaux, chauffage, serrures</span></div></div></section>' +
      '<section class="sec"><div class="sec-h"><h2 class="disp" style="font-size:26px">Nos formules</h2><span class="demo">Tarifs proposés</span></div><p class="small muted" style="margin-top:-6px">Exemple pour un loyer de 3 100 € par mois, TVA de 17 %.</p><div class="stack">' +
      D.gestion.map(function (g) { return '<div class="card" style="padding:18px;' + (g.top ? 'background:var(--ink);color:var(--cream)' : '') + '">' + (g.top ? '<span class="tag" style="margin-bottom:8px">Le plus choisi</span>' : '') + '<b style="font-size:19px;display:block">' + g.n + '</b><span class="small ' + (g.top ? '' : 'muted') + '" style="' + (g.top ? 'color:var(--cr-2)' : '') + '">' + g.s + '</span><div class="big" style="font-size:28px;margin:12px 0 2px">' + g.p + '</div><span class="tiny" style="opacity:.75">' + g.d + '</span><div class="kv" style="margin-top:10px;' + (g.top ? 'border-color:var(--cr-line)' : '') + '"><span>Pour 3 100 €</span><b>' + g.ex + '</b></div><ul style="margin:10px 0 0;padding-left:18px" class="small">' + g.l.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div>'; }).join('') +
      '</div><p class="tiny muted">État des lieux seul, hors mandat : 250 € HTVA. Repères du marché : gestion de 2 à 5 % HTVA du loyer.</p><div class="stack" style="margin-top:12px"><a class="btn or block" href="#/rdv?adv=matteo">Confier mon bien</a><a class="btn ghost block" href="' + desk('mandat.html') + '">Signer le mandat en ligne</a></div></section>' + footer();
  };

  /* ----- Agence et conseillers ----- */
  S.agence = function () {
    renderTop({ back: true, title: 'L’agence' });
    return '<section class="dark"><img src="' + img('53e5fc74') + '" alt="L’équipe IMMOTION" style="width:100%;aspect-ratio:3/2;object-fit:cover"><div class="sec"><span class="eyebrow">L’agence</span><h1 class="disp" style="font-size:36px;margin:8px 0 10px">Une agence qui bouge, <em>pour que vous avanciez.</em></h1><p class="muted" style="margin:0">IMM et MOTION : l’immobilier en mouvement. Le O qui s’étire, c’est l’élan d’un projet qui avance.</p></div></section>' +
      '<section class="sec"><div class="grid2">' + [['Les vrais chiffres', 'Chaque prix est comparé aux données officielles de l’Observatoire de l’Habitat et du STATEC.'], ['Toujours joignables', 'Rendez-vous en ligne, WhatsApp, et un assistant qui répond à toute heure.'], ['Tout suivre en ligne', 'Espace vendeur, favoris des acheteurs, signature électronique.'], ['Quatre langues', 'Français, allemand, anglais, luxembourgeois, et plus.']].map(function (x) { return '<div class="tile" style="background:var(--sand)"><b style="font-size:16px;font-style:italic;text-transform:uppercase;font-weight:900">' + x[0] + '</b><span>' + x[1] + '</span></div>'; }).join('') + '</div></section>' +
      '<section class="sec" style="padding-top:0"><h2 class="disp" style="font-size:26px;margin-bottom:12px">L’équipe</h2><div class="grid2">' + D.advisors.map(function (a) { return '<a href="#/conseiller/' + a.id + '" class="pcard"><div class="ph" style="aspect-ratio:1/1.1"><img src="' + img(a.ph) + '" alt="Portrait de ' + a.n + '" loading="lazy" style="object-position:50% 20%"></div><div class="body"><b>' + a.n + '</b><span class="tiny muted">' + a.short + '</span></div></a>'; }).join('') + '</div></section>' +
      '<section class="sec forest" id="contact"><h2 class="disp" style="font-size:28px;margin-bottom:12px">Nous écrire</h2><form id="ct" class="stack"><label class="field" style="color:var(--cr-2)">Nom<input class="input" id="ct-n" autocomplete="name" required></label><label class="field" style="color:var(--cr-2)">E-mail<input class="input" id="ct-m" type="email" placeholder="vous@exemple.lu" required></label><label class="field" style="color:var(--cr-2)">Votre message<textarea class="input" id="ct-t" rows="4" required></textarea></label><button class="btn or block">Envoyer</button><p class="tiny" style="color:var(--cr-2);margin:0">Démonstration : le message n’est pas encore envoyé.</p></form></section>' + footer();
  };
  S.agence.after = function () { $('#ct').onsubmit = function (e) { e.preventDefault(); toast('Message bien reçu, nous vous <b>répondons vite</b>'); e.target.reset(); }; };
  S.conseiller = function (p) {
    var a = D.advisors.filter(function (x) { return x.id === p[0]; })[0]; if (!a) return notFound();
    renderTop({ back: true, title: a.n });
    var biens = D.sale.filter(function (b) { return b.adv === a.id; });
    return '<section class="dark"><img src="' + img(a.ph) + '" alt="Portrait de ' + a.n + '" style="width:100%;aspect-ratio:1/1;object-fit:cover;object-position:50% 20%"><div class="sec"><span class="eyebrow">' + a.role + '</span><h1 class="disp" style="font-size:38px;margin:8px 0 6px">' + a.n + '</h1><span class="muted small">' + esc(a.zone) + '</span><div class="langs" style="margin-top:10px">' + a.langs.map(function (l) { return '<span style="background:var(--orange);color:var(--ink)">' + l + '</span>'; }).join('') + '</div><p class="muted" style="margin:14px 0 0">' + esc(a.bio) + '</p></div></section>' +
      (a.communes.length ? '<section class="sec"><h2 class="disp" style="font-size:24px;margin-bottom:10px">Ses communes</h2>' + a.communes.map(function (n) { var c = commune[n]; return c ? '<a class="crow" href="#/commune/' + encodeURIComponent(n) + '"><b class="grow">' + n + '</b><span class="num small">' + fmt(c.pa) + ' €/m²</span>' + ic('arrow', 18) + '</a>' : ''; }).join('') + '<p class="tiny muted">Prix annoncés, appartements · Observatoire de l’Habitat</p></section>' : '') +
      (biens.length ? '<section class="sec" style="padding-top:0"><h2 class="disp" style="font-size:24px;margin-bottom:10px">Ses biens</h2><div class="list">' + biens.map(saleCard).join('') + '</div></section>' : '') +
      '<div style="height:70px"></div><div class="cta-bar"><a class="btn or" href="#/rdv?adv=' + a.id + '">Prendre rendez-vous avec ' + a.n.split(' ')[0] + '</a></div>';
  };

  /* ----- Pages d'information ----- */
  S.faq = function (p, q) {
    renderTop({ back: true, title: 'Questions fréquentes' });
    var cat = q.cat || '';
    return '<section class="sec dark"><span class="eyebrow">Questions fréquentes</span><h1 class="disp" style="font-size:36px;margin:8px 0 14px">Vos questions, <em>nos réponses.</em></h1><div class="chips">' + '<a class="chip" aria-pressed="' + !cat + '" href="#/faq">Tout</a>' + Object.keys(D.faqCats).map(function (k) { return '<a class="chip" aria-pressed="' + (cat === k) + '" href="#/faq?cat=' + k + '">' + D.faqCats[k] + '</a>'; }).join('') + '</div></section>' +
      '<section class="sec">' + D.faq.filter(function (x) { return !cat || x[0] === cat; }).map(function (x, i) { return '<details class="acc"' + (i === 0 ? ' open' : '') + '><summary>' + esc(x[1]) + '</summary><p>' + esc(x[2]) + '</p></details>'; }).join('') +
      '<div class="forest card" style="padding:18px;margin-top:20px"><b style="font-size:18px">Votre question n’est pas là ?</b><p class="small" style="color:var(--cr-2);margin:6px 0 12px">L’assistant répond tout de suite, en FR, DE ou EN.</p><a class="btn or" href="#/assistant">Poser ma question</a></div></section>' + footer();
  };
  S.honoraires = function () {
    renderTop({ back: true, title: 'Honoraires' });
    return '<section class="sec dark"><span class="eyebrow">Honoraires</span><h1 class="disp" style="font-size:36px;margin:8px 0 10px">Nos tarifs, <em>noir sur blanc.</em></h1><p class="muted" style="margin:0">Pas de frais cachés, pas de surprise à la signature.</p></section>' +
      '<section class="sec stack">' + [['Vente', 'Selon votre mandat', 'Taux à compléter par l’agence', ['Estimation sur place offerte', 'Photos professionnelles et visite 3D', 'Diffusion sur les portails et en off-market', 'Visites, négociation et suivi jusqu’à l’acte']], ['Location', '1 mois de loyer', 'hors charges + TVA 17 %, partagé à parts égales entre bailleur et locataire depuis le 1er août 2024', ['Annonce, visites et sélection des dossiers', 'Vérification des pièces', 'Rédaction du bail et état des lieux d’entrée']], ['Gestion locative', 'Dès 4 % HTVA', 'des loyers encaissés, sans frais d’entrée', ['Encaissement et relances', 'Décompte annuel des charges', 'Suivi des travaux et des sinistres', 'Espace bailleur en ligne']]].map(function (x) { return '<div class="card" style="padding:18px"><span class="eyebrow">' + x[0] + '</span><div class="big" style="font-size:28px;margin:8px 0 2px">' + x[1] + '</div><span class="tiny muted">' + x[2] + '</span><ul class="small" style="margin:10px 0 0;padding-left:18px">' + x[3].map(function (l) { return '<li>' + l + '</li>'; }).join('') + '</ul></div>'; }).join('') +
      '<div class="dark card" style="padding:18px"><b>Toujours offert</b><ul class="small" style="margin:8px 0 0;padding-left:18px;color:var(--cr-2)"><li>Estimation en ligne et sur place</li><li>Accès à la carte des 100 communes</li><li>Newsletter mensuelle du marché</li><li>Assistant IMMOTION, 7j/7</li></ul></div><a class="btn ghost block" href="' + desk('honoraires.html') + '">Barème complet et calculateur</a></section>' + footer();
  };
  S.newsletter = function () {
    renderTop({ back: true, title: 'Newsletter' });
    var ok = store.get('nl', false);
    return '<section class="sec dark"><span class="eyebrow">Newsletter mensuelle</span><h1 class="disp" style="font-size:38px;margin:8px 0 10px">Le marché, <em>chiffres à l’appui.</em></h1><p class="muted">Chaque mois : taux, prix par commune, lois qui changent. Uniquement des chiffres vérifiés, avec leurs sources.</p>' +
      '<div class="card" style="padding:16px;background:rgba(237,230,214,.06);margin:16px 0 0"><span class="small" style="color:var(--cr-2)">Taux variable moyen des crédits immobiliers</span><div class="row" style="align-items:baseline;gap:10px;margin-top:4px"><span class="big" style="color:var(--orange)">3,19 %</span><span class="small" style="color:var(--cr-2)">en juin 2026 (BCL)</span></div></div></section>' +
      '<section class="sec">' + (ok ? '<div class="empty"><div class="okmark">' + ic('check', 40) + '</div><b style="font-size:20px">Bienvenue !</b><p class="small">Le prochain numéro arrive au début du mois.</p></div>' :
        '<form id="nl" class="stack"><label class="field">Votre e-mail<input class="input" id="nl-m" type="email" placeholder="vous@exemple.lu" required></label><b class="small">Vos centres d’intérêt</b><div class="row" style="flex-wrap:wrap;gap:8px">' + ['Acheter', 'Vendre', 'Louer', 'Investir'].map(function (x, i) { return '<button type="button" class="chip" data-nl aria-pressed="' + (i === 0) + '">' + x + '</button>'; }).join('') + '</div><label class="row small"><input type="checkbox" required style="width:20px;height:20px;accent-color:var(--orange)"> J’accepte de recevoir la newsletter. Désinscription en un clic.</label><button class="btn or block">S’abonner</button></form>') + '</section>' + footer();
  };
  S.newsletter.after = function () {
    $$('[data-nl]').forEach(function (b) { b.onclick = function () { b.setAttribute('aria-pressed', b.getAttribute('aria-pressed') !== 'true'); }; });
    var f = $('#nl'); if (f) f.onsubmit = function (e) { e.preventDefault(); store.set('nl', true); vibrate(); rerender(); };
  };
  function notFound() { renderTop({ back: true, title: 'Introuvable' }); return '<div class="empty" style="padding-top:60px"><div class="ei">' + ic('search', 28) + '</div><b>Ce bien a déjà trouvé preneur.</b><p class="small">La page demandée n’existe plus.</p><a class="btn or" href="#/biens">Voir les biens</a></div>'; }

  /* ================= Navigation ================= */
  var curTab = '', stack = [];
  try { stack = JSON.parse(sessionStorage.getItem('imx-stack') || '[]'); } catch (e) {}
  function parse(h) {
    h = (h || '').replace(/^#\/?/, '');
    var qi = h.indexOf('?'), qs = qi >= 0 ? h.slice(qi + 1) : '', path = (qi >= 0 ? h.slice(0, qi) : h).split('/').filter(Boolean);
    var q = {}; qs.split('&').forEach(function (kv) { if (!kv) return; var p = kv.split('='); q[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || ''); });
    return { name: path[0] || '', params: path.slice(1), q: q };
  }
  function tabFor(n) { return { '': '', biens: 'biens', bien: 'biens', location: 'biens', estimer: 'estimer', assistant: 'assistant', moi: 'moi' }[n]; }
  function render(dir, keepScroll) {
    closeSheet();
    var r = parse(location.hash), fn = S[r.name] || notFound;
    var t = tabFor(r.name); if (t !== undefined) curTab = t;
    var doIt = function () {
      document.documentElement.dataset.dir = dir || 'none';
      view.innerHTML = '<div class="view">' + (S[r.name] ? fn(r.params, r.q) : notFound()) + '</div>';
      renderTabs(curTab);
      if (fn.after) fn.after(r.params, r.q);
      if (!keepScroll) window.scrollTo(0, 0);
      var title = { '': 'IMMOTION', biens: 'Biens', estimer: 'Estimation', assistant: 'Assistant', moi: 'Mon espace' }[r.name];
      document.title = (title || ($('.top .ttl') && $('.top .ttl').textContent) || 'IMMOTION') + (title === 'IMMOTION' ? '' : ' · IMMOTION');
    };
    if (document.startViewTransition && dir && dir !== 'none' && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) document.startViewTransition(doIt);
    else doIt();
  }
  function rerender(toTop) { render('none', !toTop); }
  function go(h) { location.hash = h; }
  function goBack() { if (stack.length > 1) history.back(); else go('#/'); }
  window.addEventListener('hashchange', function () {
    var h = location.hash || '#/', dir = 'fwd';
    if (stack.length > 1 && stack[stack.length - 2] === h) { stack.pop(); dir = 'back'; } else { stack.push(h); }
    var r = parse(h); if (dir !== 'back' && ['', 'biens', 'estimer', 'assistant', 'moi'].indexOf(r.name) >= 0 && !r.params.length) { stack = [h]; dir = 'none'; }
    try { sessionStorage.setItem('imx-stack', JSON.stringify(stack.slice(-30))); } catch (e) {}
    render(dir);
  });

  /* Liste des communes pour la saisie */
  var dl = document.createElement('datalist'); dl.id = 'dl-communes'; dl.innerHTML = CM.map(function (c) { return '<option value="' + esc(c.n) + '">'; }).join(''); document.body.appendChild(dl);

  if (!stack.length) stack = [location.hash || '#/'];
  render('none');

  /* Service worker : appli disponible hors connexion */
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) navigator.serviceWorker.register('sw.js').catch(function () {});
})();
