/* IMMOTION · service worker : l'appli s'ouvre instantanément et fonctionne hors connexion. */
var CACHE = 'immotion-deb90c5141';
var SHELL = ["app.html", "manifest.webmanifest", "assets/favicon.svg", "assets/agent-config.js", "assets/assistant.js", "assets/app/app.css", "assets/app/app.js", "assets/app/data.js", "assets/app/img/0098dd5d.jpg", "assets/app/img/18bfe52f.jpg", "assets/app/img/28ff79e3.jpg", "assets/app/img/319542d0.jpg", "assets/app/img/3f6583a2.jpg", "assets/app/img/46019e5f.jpg", "assets/app/img/52ae2091.jpg", "assets/app/img/53e5fc74.jpg", "assets/app/img/6b818eaa.jpg", "assets/app/img/6d98eb67.jpg", "assets/app/img/73534450.jpg", "assets/app/img/73ef1c78.jpg", "assets/app/img/7a1c6652.jpg", "assets/app/img/7b601c6d.jpg", "assets/app/img/81939e9a.jpg", "assets/app/img/8908add6.jpg", "assets/app/img/a23ba3f8.jpg", "assets/app/img/aac41911.jpg", "assets/app/img/abdda372.jpg", "assets/app/img/b29f763c.jpg", "assets/app/img/d149266c.jpg", "assets/app/img/d4c9c48e.jpg", "assets/app/img/d70f1a97.jpg", "assets/app/img/e374f677.jpg", "assets/app/img/e3f724f3.jpg", "assets/app/img/efe89f88.jpg", "assets/app/img/fff76aeb.jpg", "assets/app/icons/apple-180.png", "assets/app/icons/icon-192.png", "assets/app/icons/icon-512.png", "assets/app/icons/maskable-512.png"];
self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(SHELL); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k.indexOf('immotion-') === 0 && k !== CACHE; }).map(function (k) { return caches.delete(k); })); }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  var sameOrigin = url.origin === self.location.origin;
  var isFont = /fonts\.(googleapis|gstatic)\.com$/.test(url.hostname);
  if (!sameOrigin && !isFont) return;
  if (req.mode === 'navigate') {
    /* Pages : le réseau d'abord (contenu à jour), le cache si hors connexion. */
    e.respondWith(fetch(req).then(function (res) {
      var copy = res.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }); return res;
    }).catch(function () { return caches.match(req).then(function (r) { return r || caches.match('app.html'); }); }));
    return;
  }
  /* Fichiers : le cache d'abord (instantané), mis à jour en arrière-plan. */
  e.respondWith(caches.match(req).then(function (hit) {
    var net = fetch(req).then(function (res) {
      if (res && (res.ok || res.type === 'opaque')) { var copy = res.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }); }
      return res;
    }).catch(function () { return hit; });
    return hit || net;
  }));
});
